--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6 (Debian 10.6-1.pgdg90+1)
-- Dumped by pg_dump version 10.6 (Debian 10.6-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_level_fkey6;
ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_level_fkey5;
ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_level_fkey4;
ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_level_fkey3;
ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_level_fkey2;
ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_level_fkey1;
ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_level_fkey;
ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_id_arbre_fkey;
ALTER TABLE ONLY public.espece DROP CONSTRAINT espece_id_genre_fkey;
ALTER TABLE ONLY public.arbre DROP CONSTRAINT arbre_id_manip_fkey;
ALTER TABLE ONLY public.arbre DROP CONSTRAINT arbre_genre_fkey;
ALTER TABLE ONLY public.arbre DROP CONSTRAINT arbre_esp_fkey;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_uuid_arbre_fkey;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_level_fkey6;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_level_fkey5;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_level_fkey4;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_level_fkey3;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_level_fkey2;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_level_fkey1;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_level_fkey;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_uuid_arbre_fkey;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_level_fkey6;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_level_fkey5;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_level_fkey4;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_level_fkey3;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_level_fkey2;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_level_fkey1;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_level_fkey;
ALTER TABLE ONLY fraxpyr.brin DROP CONSTRAINT brin_uuid_manip_fkey;
ALTER TABLE ONLY fraxpyr.brin DROP CONSTRAINT brin_uuid_arbre_fkey;
ALTER TABLE ONLY fraxpyr.arbre DROP CONSTRAINT arbre_uuid_manip_fkey;
ALTER TABLE ONLY fraxpyr.arbre DROP CONSTRAINT arbre_genre_fkey;
ALTER TABLE ONLY fraxpyr.arbre DROP CONSTRAINT arbre_esp_fkey;
ALTER TABLE ONLY public.manip DROP CONSTRAINT unik_manip;
ALTER TABLE ONLY public.releve DROP CONSTRAINT releve_pkey;
ALTER TABLE ONLY public.manip DROP CONSTRAINT manip_pkey;
ALTER TABLE ONLY public.level7_v1 DROP CONSTRAINT level7_pkey;
ALTER TABLE ONLY public.level6_v1 DROP CONSTRAINT level6_pkey;
ALTER TABLE ONLY public.level5_v1 DROP CONSTRAINT level5_pkey;
ALTER TABLE ONLY public.level4_v1 DROP CONSTRAINT level4_pkey;
ALTER TABLE ONLY public.level3_v1 DROP CONSTRAINT level3_pkey;
ALTER TABLE ONLY public.level2_v1 DROP CONSTRAINT level2_pkey;
ALTER TABLE ONLY public.level1_v1 DROP CONSTRAINT level1_id_level_key;
ALTER TABLE ONLY public.genre DROP CONSTRAINT genre_pkey;
ALTER TABLE ONLY public.espece DROP CONSTRAINT espece_pkey;
ALTER TABLE ONLY public.code_sp DROP CONSTRAINT code_sp_pkey;
ALTER TABLE ONLY public.arbre DROP CONSTRAINT arbre_pkey;
ALTER TABLE ONLY fraxpyr.manip DROP CONSTRAINT unik_manip;
ALTER TABLE ONLY fraxpyr.site DROP CONSTRAINT site_pkey;
ALTER TABLE ONLY fraxpyr.releve DROP CONSTRAINT releve_pkey;
ALTER TABLE ONLY fraxpyr.releve_cepee DROP CONSTRAINT releve_cepee_pkey;
ALTER TABLE ONLY fraxpyr.manip DROP CONSTRAINT manip_pkey;
ALTER TABLE ONLY fraxpyr.arbre DROP CONSTRAINT arbre_pkey;
ALTER TABLE public.releve ALTER COLUMN id_releve DROP DEFAULT;
ALTER TABLE public.manip ALTER COLUMN id_manip DROP DEFAULT;
ALTER TABLE public.level2_v1 ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.level1_v1 ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.genre ALTER COLUMN id_genre DROP DEFAULT;
ALTER TABLE public.espece ALTER COLUMN id_espece DROP DEFAULT;
ALTER TABLE public.code_sp ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.arbre ALTER COLUMN id_arbre DROP DEFAULT;
DROP SEQUENCE public.releve_id_releve_seq;
DROP TABLE public.releve;
DROP SEQUENCE public.manip_id_manip_seq;
DROP TABLE public.manip;
DROP TABLE public.level7_v1;
DROP TABLE public.level7;
DROP TABLE public.level6_v1;
DROP TABLE public.level6;
DROP TABLE public.level5_v1;
DROP TABLE public.level5;
DROP TABLE public.level4_v1;
DROP TABLE public.level4;
DROP TABLE public.level2;
DROP TABLE public.level1;
DROP SEQUENCE public.level1_id_level_seq;
DROP TABLE public.level1_v1;
DROP SEQUENCE public.genre_id_genre_seq;
DROP SEQUENCE public.espece_id_espece_seq;
DROP SEQUENCE public.code_sp_id_seq;
DROP TABLE public.code_sp;
DROP SEQUENCE public.arbre_id_arbre_seq;
DROP TABLE public.arbre;
DROP TABLE fraxpyr.site;
DROP TABLE fraxpyr.releve_cepee;
DROP TABLE fraxpyr.releve;
DROP TABLE fraxpyr.manip;
DROP TABLE fraxpyr.cepee;
DROP TABLE fraxpyr.brin;
DROP TABLE fraxpyr.arbre;
DROP TABLE public.level3_v1;
DROP TABLE public.level3;
DROP SEQUENCE public.level2_id_level_seq;
DROP TABLE public.level2_v1;
DROP TABLE public.genre;
DROP TABLE public.espece;
DROP SCHEMA public;
DROP SCHEMA fraxpyr;
--
-- Name: fraxpyr; Type: SCHEMA; Schema: -; Owner: dynuser
--

CREATE SCHEMA fraxpyr;


ALTER SCHEMA fraxpyr OWNER TO dynuser;

--
-- Name: SCHEMA fraxpyr; Type: COMMENT; Schema: -; Owner: dynuser
--

COMMENT ON SCHEMA fraxpyr IS 'Schéma des données Fraxpyr v2 (prenant en compte la distinction cépée / non cépée)';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: espece; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.espece (
    id_espece integer NOT NULL,
    nom character varying(50),
    id_genre integer,
    exo boolean,
    sp character varying(2)
);


ALTER TABLE public.espece OWNER TO dynuser;

--
-- Name: genre; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.genre (
    id_genre integer NOT NULL,
    nom character varying(20)
);


ALTER TABLE public.genre OWNER TO dynuser;

--
-- Name: level2_v1; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level2_v1 (
    id_level integer NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    version character varying
);


ALTER TABLE public.level2_v1 OWNER TO dynuser;

--
-- Name: TABLE level2_v1; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level2_v1 IS 'Table des DMH niveau 2';


--
-- Name: level2_id_level_seq; Type: SEQUENCE; Schema: public; Owner: dynuser
--

CREATE SEQUENCE public.level2_id_level_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.level2_id_level_seq OWNER TO dynuser;

--
-- Name: level2_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dynuser
--

ALTER SEQUENCE public.level2_id_level_seq OWNED BY public.level2_v1.id_level;


--
-- Name: level3; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level3 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    def_en character varying,
    def_fr character varying,
    valeur_seuil_en character varying,
    valeur_seuil_fr character varying,
    typo_simp boolean,
    code_level character varying
);


ALTER TABLE public.level3 OWNER TO dynuser;

--
-- Name: TABLE level3; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level3 IS 'Table des DMH niveau 3';


--
-- Name: level3_v1; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level3_v1 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    version character varying,
    def_en character varying,
    def_fr character varying,
    valeur_seuil_en character varying,
    valeur_seuil_fr character varying,
    typo_simp boolean,
    code_level character varying
);


ALTER TABLE public.level3_v1 OWNER TO dynuser;

--
-- Name: TABLE level3_v1; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level3_v1 IS 'Table des DMH niveau 3';


--
-- Name: arbre; Type: TABLE; Schema: fraxpyr; Owner: dynuser
--

CREATE TABLE fraxpyr.arbre (
    nom_arbre character varying,
    morpho character varying,
    forme character varying,
    esp integer,
    genre integer,
    localisation character varying,
    lon numeric,
    lat numeric,
    commentaire character varying,
    date_creation timestamp without time zone DEFAULT now(),
    uuid_arbre uuid NOT NULL,
    uuid_manip uuid,
    geom public.geometry,
    num_arbre character varying,
    photo character varying
);


ALTER TABLE fraxpyr.arbre OWNER TO dynuser;

--
-- Name: TABLE arbre; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON TABLE fraxpyr.arbre IS 'Table des arbres observés';


--
-- Name: COLUMN arbre.nom_arbre; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.arbre.nom_arbre IS 'numéro de l''arbre';


--
-- Name: COLUMN arbre.morpho; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.arbre.morpho IS 'Morphologie de l''arbre';


--
-- Name: COLUMN arbre.forme; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.arbre.forme IS 'Forme de l''arbre';


--
-- Name: COLUMN arbre.esp; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.arbre.esp IS 'Code de l''espèce';


--
-- Name: COLUMN arbre.genre; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.arbre.genre IS 'Code du genre';


--
-- Name: brin; Type: TABLE; Schema: fraxpyr; Owner: dynuser
--

CREATE TABLE fraxpyr.brin (
    num_brin character varying,
    dbh character varying,
    forme character varying,
    gestion character varying,
    htot real,
    hfut real,
    dhref integer,
    nb_br20_fut integer,
    nb_br20sup_fut integer,
    nb_br20_tete integer,
    nb_br20sup_tete integer,
    commentaire character varying,
    date_creation timestamp without time zone DEFAULT now(),
    dia_br character varying,
    photo character varying,
    uuid_arbre uuid NOT NULL,
    uuid_manip uuid NOT NULL,
    uuid_brin uuid,
    geom public.geometry,
    type character varying
);


ALTER TABLE fraxpyr.brin OWNER TO dynuser;

--
-- Name: TABLE brin; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON TABLE fraxpyr.brin IS 'Table des brins observés';


--
-- Name: COLUMN brin.num_brin; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.brin.num_brin IS 'numéro du brin';


--
-- Name: COLUMN brin.dbh; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.brin.dbh IS 'diamètre à 1.30m';


--
-- Name: COLUMN brin.forme; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.brin.forme IS 'Forme du brin';


--
-- Name: cepee; Type: TABLE; Schema: fraxpyr; Owner: dynuser
--

CREATE TABLE fraxpyr.cepee (
    nb_brin integer,
    pbase real,
    uuid_arbre uuid NOT NULL,
    uuid_cepee uuid,
    uuid_manip uuid NOT NULL,
    date_creation timestamp without time zone DEFAULT now(),
    commentaire character varying
);


ALTER TABLE fraxpyr.cepee OWNER TO dynuser;

--
-- Name: manip; Type: TABLE; Schema: fraxpyr; Owner: dynuser
--

CREATE TABLE fraxpyr.manip (
    id_site character varying,
    date date,
    obs character varying,
    notateur character varying,
    manip character varying,
    date_creation timestamp without time zone DEFAULT now(),
    uuid_manip uuid NOT NULL
);


ALTER TABLE fraxpyr.manip OWNER TO dynuser;

--
-- Name: TABLE manip; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON TABLE fraxpyr.manip IS 'Table des manips (ie une session sur un plot ou une placette)';


--
-- Name: releve; Type: TABLE; Schema: fraxpyr; Owner: dynuser
--

CREATE TABLE fraxpyr.releve (
    num_brin character varying,
    dmh character varying,
    qte integer,
    level integer,
    date timestamp without time zone DEFAULT now(),
    uuid_releve uuid NOT NULL,
    uuid_arbre uuid,
    uuid_brin uuid,
    nom_arbre character varying
);


ALTER TABLE fraxpyr.releve OWNER TO dynuser;

--
-- Name: TABLE releve; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON TABLE fraxpyr.releve IS 'Table des relevés terrain pour fraxpyr';


--
-- Name: COLUMN releve.num_brin; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON COLUMN fraxpyr.releve.num_brin IS 'numéro du brin porteur du dmh';


--
-- Name: releve_cepee; Type: TABLE; Schema: fraxpyr; Owner: dynuser
--

CREATE TABLE fraxpyr.releve_cepee (
    num_arbre character varying,
    dmh character varying,
    qte integer,
    level integer,
    date timestamp without time zone DEFAULT now(),
    uuid_releve uuid NOT NULL,
    uuid_arbre uuid,
    uuid_cepee uuid
);


ALTER TABLE fraxpyr.releve_cepee OWNER TO dynuser;

--
-- Name: TABLE releve_cepee; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON TABLE fraxpyr.releve_cepee IS 'Table des relevés terrain pour fraxpyr';


--
-- Name: site; Type: TABLE; Schema: fraxpyr; Owner: dynuser
--

CREATE TABLE fraxpyr.site (
    id_site integer NOT NULL,
    site character varying
);


ALTER TABLE fraxpyr.site OWNER TO dynuser;

--
-- Name: TABLE site; Type: COMMENT; Schema: fraxpyr; Owner: dynuser
--

COMMENT ON TABLE fraxpyr.site IS 'Table des sites';


--
-- Name: arbre; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.arbre (
    id_arbre integer NOT NULL,
    num_arbre character varying,
    dbh character varying,
    statut character varying,
    id_manip integer NOT NULL,
    stade integer,
    esp integer,
    genre integer
);


ALTER TABLE public.arbre OWNER TO dynuser;

--
-- Name: TABLE arbre; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.arbre IS 'Table des arbres observés';


--
-- Name: COLUMN arbre.id_arbre; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.arbre.id_arbre IS 'identifiant automatique';


--
-- Name: COLUMN arbre.num_arbre; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.arbre.num_arbre IS 'numéro de l''arbre';


--
-- Name: COLUMN arbre.dbh; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.arbre.dbh IS 'diamètre à 1.30m';


--
-- Name: COLUMN arbre.statut; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.arbre.statut IS 'Statut de l''arbre';


--
-- Name: COLUMN arbre.id_manip; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.arbre.id_manip IS 'Identifiant de la manip';


--
-- Name: COLUMN arbre.stade; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.arbre.stade IS 'stade de saproxylation (si arbre mort)';


--
-- Name: COLUMN arbre.esp; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.arbre.esp IS 'Code de l''espèce';


--
-- Name: COLUMN arbre.genre; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.arbre.genre IS 'Code du genre';


--
-- Name: arbre_id_arbre_seq; Type: SEQUENCE; Schema: public; Owner: dynuser
--

CREATE SEQUENCE public.arbre_id_arbre_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.arbre_id_arbre_seq OWNER TO dynuser;

--
-- Name: arbre_id_arbre_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dynuser
--

ALTER SEQUENCE public.arbre_id_arbre_seq OWNED BY public.arbre.id_arbre;


--
-- Name: code_sp; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.code_sp (
    id integer NOT NULL,
    name character varying,
    code character varying
);


ALTER TABLE public.code_sp OWNER TO dynuser;

--
-- Name: TABLE code_sp; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.code_sp IS 'correspondances code espèce - nom espèce';


--
-- Name: code_sp_id_seq; Type: SEQUENCE; Schema: public; Owner: dynuser
--

CREATE SEQUENCE public.code_sp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.code_sp_id_seq OWNER TO dynuser;

--
-- Name: code_sp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dynuser
--

ALTER SEQUENCE public.code_sp_id_seq OWNED BY public.code_sp.id;


--
-- Name: espece_id_espece_seq; Type: SEQUENCE; Schema: public; Owner: dynuser
--

CREATE SEQUENCE public.espece_id_espece_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.espece_id_espece_seq OWNER TO dynuser;

--
-- Name: espece_id_espece_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dynuser
--

ALTER SEQUENCE public.espece_id_espece_seq OWNED BY public.espece.id_espece;


--
-- Name: genre_id_genre_seq; Type: SEQUENCE; Schema: public; Owner: dynuser
--

CREATE SEQUENCE public.genre_id_genre_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genre_id_genre_seq OWNER TO dynuser;

--
-- Name: genre_id_genre_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dynuser
--

ALTER SEQUENCE public.genre_id_genre_seq OWNED BY public.genre.id_genre;


--
-- Name: level1_v1; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level1_v1 (
    id_level integer NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    version character varying
);


ALTER TABLE public.level1_v1 OWNER TO dynuser;

--
-- Name: TABLE level1_v1; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level1_v1 IS 'Table des DMH premier niveau';


--
-- Name: level1_id_level_seq; Type: SEQUENCE; Schema: public; Owner: dynuser
--

CREATE SEQUENCE public.level1_id_level_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.level1_id_level_seq OWNER TO dynuser;

--
-- Name: level1_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dynuser
--

ALTER SEQUENCE public.level1_id_level_seq OWNED BY public.level1_v1.id_level;


--
-- Name: level1; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level1 (
    id_level integer DEFAULT nextval('public.level1_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying
);


ALTER TABLE public.level1 OWNER TO dynuser;

--
-- Name: TABLE level1; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level1 IS 'Table des DMH premier niveau';


--
-- Name: level2; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level2 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer
);


ALTER TABLE public.level2 OWNER TO dynuser;

--
-- Name: TABLE level2; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level2 IS 'Table des DMH niveau 2';


--
-- Name: level4; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level4 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer
);


ALTER TABLE public.level4 OWNER TO dynuser;

--
-- Name: TABLE level4; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level4 IS 'Table des DMH niveau 4';


--
-- Name: level4_v1; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level4_v1 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    version character varying
);


ALTER TABLE public.level4_v1 OWNER TO dynuser;

--
-- Name: TABLE level4_v1; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level4_v1 IS 'Table des DMH niveau 4';


--
-- Name: level5; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level5 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer
);


ALTER TABLE public.level5 OWNER TO dynuser;

--
-- Name: TABLE level5; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level5 IS 'Table des DMH niveau 5';


--
-- Name: level5_v1; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level5_v1 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    version character varying
);


ALTER TABLE public.level5_v1 OWNER TO dynuser;

--
-- Name: TABLE level5_v1; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level5_v1 IS 'Table des DMH niveau 3';


--
-- Name: level6; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level6 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    version character varying
);


ALTER TABLE public.level6 OWNER TO dynuser;

--
-- Name: TABLE level6; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level6 IS 'Table des DMH niveau 6';


--
-- Name: level6_v1; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level6_v1 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    version character varying
);


ALTER TABLE public.level6_v1 OWNER TO dynuser;

--
-- Name: TABLE level6_v1; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level6_v1 IS 'Table des DMH niveau 6';


--
-- Name: level7; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level7 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    se character(3),
    def_en character varying,
    def_fr character varying,
    version character varying,
    valeur_seuil_en character varying,
    valeur_seuil_fr character varying,
    choix_seuil_en character varying,
    choix_seuil_fr character varying
);


ALTER TABLE public.level7 OWNER TO dynuser;

--
-- Name: TABLE level7; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level7 IS 'Table des DMH niveau 7';


--
-- Name: level7_v1; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.level7_v1 (
    id_level integer DEFAULT nextval('public.level2_id_level_seq'::regclass) NOT NULL,
    level integer,
    label_fr character varying,
    label_en character varying,
    level_up integer,
    se character(3),
    def_en character varying,
    def_fr character varying,
    version character varying,
    valeur_seuil_en character varying,
    valeur_seuil_fr character varying,
    choix_seuil_en character varying,
    choix_seuil_fr character varying
);


ALTER TABLE public.level7_v1 OWNER TO dynuser;

--
-- Name: TABLE level7_v1; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.level7_v1 IS 'Table des DMH niveau 7';


--
-- Name: manip; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.manip (
    id_site character varying,
    date date,
    id_plot character varying,
    obs character varying,
    notateur character varying,
    id_manip integer NOT NULL,
    manip character varying
);


ALTER TABLE public.manip OWNER TO dynuser;

--
-- Name: TABLE manip; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.manip IS 'Table des manips (ie une session sur un plot ou une placette)';


--
-- Name: manip_id_manip_seq; Type: SEQUENCE; Schema: public; Owner: dynuser
--

CREATE SEQUENCE public.manip_id_manip_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manip_id_manip_seq OWNER TO dynuser;

--
-- Name: manip_id_manip_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dynuser
--

ALTER SEQUENCE public.manip_id_manip_seq OWNED BY public.manip.id_manip;


--
-- Name: releve; Type: TABLE; Schema: public; Owner: dynuser
--

CREATE TABLE public.releve (
    id_releve integer NOT NULL,
    num_arbre character varying,
    dmh character varying,
    qte integer,
    level integer,
    id_arbre integer,
    date timestamp without time zone DEFAULT now()
);


ALTER TABLE public.releve OWNER TO dynuser;

--
-- Name: TABLE releve; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON TABLE public.releve IS 'Table des relevés de DMH';


--
-- Name: COLUMN releve.num_arbre; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.releve.num_arbre IS '"nom" de l''arbre';


--
-- Name: COLUMN releve.id_arbre; Type: COMMENT; Schema: public; Owner: dynuser
--

COMMENT ON COLUMN public.releve.id_arbre IS 'identifiant de l''arbre';


--
-- Name: releve_id_releve_seq; Type: SEQUENCE; Schema: public; Owner: dynuser
--

CREATE SEQUENCE public.releve_id_releve_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.releve_id_releve_seq OWNER TO dynuser;

--
-- Name: releve_id_releve_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dynuser
--

ALTER SEQUENCE public.releve_id_releve_seq OWNED BY public.releve.id_releve;


--
-- Name: arbre id_arbre; Type: DEFAULT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.arbre ALTER COLUMN id_arbre SET DEFAULT nextval('public.arbre_id_arbre_seq'::regclass);


--
-- Name: code_sp id; Type: DEFAULT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.code_sp ALTER COLUMN id SET DEFAULT nextval('public.code_sp_id_seq'::regclass);


--
-- Name: espece id_espece; Type: DEFAULT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.espece ALTER COLUMN id_espece SET DEFAULT nextval('public.espece_id_espece_seq'::regclass);


--
-- Name: genre id_genre; Type: DEFAULT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.genre ALTER COLUMN id_genre SET DEFAULT nextval('public.genre_id_genre_seq'::regclass);


--
-- Name: level1_v1 id_level; Type: DEFAULT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level1_v1 ALTER COLUMN id_level SET DEFAULT nextval('public.level1_id_level_seq'::regclass);


--
-- Name: level2_v1 id_level; Type: DEFAULT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level2_v1 ALTER COLUMN id_level SET DEFAULT nextval('public.level2_id_level_seq'::regclass);


--
-- Name: manip id_manip; Type: DEFAULT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.manip ALTER COLUMN id_manip SET DEFAULT nextval('public.manip_id_manip_seq'::regclass);


--
-- Name: releve id_releve; Type: DEFAULT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve ALTER COLUMN id_releve SET DEFAULT nextval('public.releve_id_releve_seq'::regclass);


--
-- Data for Name: arbre; Type: TABLE DATA; Schema: fraxpyr; Owner: dynuser
--

COPY fraxpyr.arbre (nom_arbre, morpho, forme, esp, genre, localisation, lon, lat, commentaire, date_creation, uuid_arbre, uuid_manip, geom, num_arbre, photo) FROM stdin;
\.
COPY fraxpyr.arbre (nom_arbre, morpho, forme, esp, genre, localisation, lon, lat, commentaire, date_creation, uuid_arbre, uuid_manip, geom, num_arbre, photo) FROM '$$PATH$$/4791.dat';

--
-- Data for Name: brin; Type: TABLE DATA; Schema: fraxpyr; Owner: dynuser
--

COPY fraxpyr.brin (num_brin, dbh, forme, gestion, htot, hfut, dhref, nb_br20_fut, nb_br20sup_fut, nb_br20_tete, nb_br20sup_tete, commentaire, date_creation, dia_br, photo, uuid_arbre, uuid_manip, uuid_brin, geom, type) FROM stdin;
\.
COPY fraxpyr.brin (num_brin, dbh, forme, gestion, htot, hfut, dhref, nb_br20_fut, nb_br20sup_fut, nb_br20_tete, nb_br20sup_tete, commentaire, date_creation, dia_br, photo, uuid_arbre, uuid_manip, uuid_brin, geom, type) FROM '$$PATH$$/4792.dat';

--
-- Data for Name: cepee; Type: TABLE DATA; Schema: fraxpyr; Owner: dynuser
--

COPY fraxpyr.cepee (nb_brin, pbase, uuid_arbre, uuid_cepee, uuid_manip, date_creation, commentaire) FROM stdin;
\.
COPY fraxpyr.cepee (nb_brin, pbase, uuid_arbre, uuid_cepee, uuid_manip, date_creation, commentaire) FROM '$$PATH$$/4793.dat';

--
-- Data for Name: manip; Type: TABLE DATA; Schema: fraxpyr; Owner: dynuser
--

COPY fraxpyr.manip (id_site, date, obs, notateur, manip, date_creation, uuid_manip) FROM stdin;
\.
COPY fraxpyr.manip (id_site, date, obs, notateur, manip, date_creation, uuid_manip) FROM '$$PATH$$/4790.dat';

--
-- Data for Name: releve; Type: TABLE DATA; Schema: fraxpyr; Owner: dynuser
--

COPY fraxpyr.releve (num_brin, dmh, qte, level, date, uuid_releve, uuid_arbre, uuid_brin, nom_arbre) FROM stdin;
\.
COPY fraxpyr.releve (num_brin, dmh, qte, level, date, uuid_releve, uuid_arbre, uuid_brin, nom_arbre) FROM '$$PATH$$/4794.dat';

--
-- Data for Name: releve_cepee; Type: TABLE DATA; Schema: fraxpyr; Owner: dynuser
--

COPY fraxpyr.releve_cepee (num_arbre, dmh, qte, level, date, uuid_releve, uuid_arbre, uuid_cepee) FROM stdin;
\.
COPY fraxpyr.releve_cepee (num_arbre, dmh, qte, level, date, uuid_releve, uuid_arbre, uuid_cepee) FROM '$$PATH$$/4795.dat';

--
-- Data for Name: site; Type: TABLE DATA; Schema: fraxpyr; Owner: dynuser
--

COPY fraxpyr.site (id_site, site) FROM stdin;
\.
COPY fraxpyr.site (id_site, site) FROM '$$PATH$$/4796.dat';

--
-- Data for Name: arbre; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.arbre (id_arbre, num_arbre, dbh, statut, id_manip, stade, esp, genre) FROM stdin;
\.
COPY public.arbre (id_arbre, num_arbre, dbh, statut, id_manip, stade, esp, genre) FROM '$$PATH$$/4774.dat';

--
-- Data for Name: code_sp; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.code_sp (id, name, code) FROM stdin;
\.
COPY public.code_sp (id, name, code) FROM '$$PATH$$/4776.dat';

--
-- Data for Name: espece; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.espece (id_espece, nom, id_genre, exo, sp) FROM stdin;
\.
COPY public.espece (id_espece, nom, id_genre, exo, sp) FROM '$$PATH$$/4769.dat';

--
-- Data for Name: genre; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.genre (id_genre, nom) FROM stdin;
\.
COPY public.genre (id_genre, nom) FROM '$$PATH$$/4770.dat';

--
-- Data for Name: level1; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level1 (id_level, level, label_fr, label_en) FROM stdin;
\.
COPY public.level1 (id_level, level, label_fr, label_en) FROM '$$PATH$$/4797.dat';

--
-- Data for Name: level1_v1; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level1_v1 (id_level, level, label_fr, label_en, version) FROM stdin;
\.
COPY public.level1_v1 (id_level, level, label_fr, label_en, version) FROM '$$PATH$$/4780.dat';

--
-- Data for Name: level2; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level2 (id_level, level, label_fr, label_en, level_up) FROM stdin;
\.
COPY public.level2 (id_level, level, label_fr, label_en, level_up) FROM '$$PATH$$/4798.dat';

--
-- Data for Name: level2_v1; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level2_v1 (id_level, level, label_fr, label_en, level_up, version) FROM stdin;
\.
COPY public.level2_v1 (id_level, level, label_fr, label_en, level_up, version) FROM '$$PATH$$/4771.dat';

--
-- Data for Name: level3; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level3 (id_level, level, label_fr, label_en, level_up, def_en, def_fr, valeur_seuil_en, valeur_seuil_fr, typo_simp, code_level) FROM stdin;
\.
COPY public.level3 (id_level, level, label_fr, label_en, level_up, def_en, def_fr, valeur_seuil_en, valeur_seuil_fr, typo_simp, code_level) FROM '$$PATH$$/4799.dat';

--
-- Data for Name: level3_v1; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level3_v1 (id_level, level, label_fr, label_en, level_up, version, def_en, def_fr, valeur_seuil_en, valeur_seuil_fr, typo_simp, code_level) FROM stdin;
\.
COPY public.level3_v1 (id_level, level, label_fr, label_en, level_up, version, def_en, def_fr, valeur_seuil_en, valeur_seuil_fr, typo_simp, code_level) FROM '$$PATH$$/4773.dat';

--
-- Data for Name: level4; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level4 (id_level, level, label_fr, label_en, level_up) FROM stdin;
\.
COPY public.level4 (id_level, level, label_fr, label_en, level_up) FROM '$$PATH$$/4800.dat';

--
-- Data for Name: level4_v1; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level4_v1 (id_level, level, label_fr, label_en, level_up, version) FROM stdin;
\.
COPY public.level4_v1 (id_level, level, label_fr, label_en, level_up, version) FROM '$$PATH$$/4782.dat';

--
-- Data for Name: level5; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level5 (id_level, level, label_fr, label_en, level_up) FROM stdin;
\.
COPY public.level5 (id_level, level, label_fr, label_en, level_up) FROM '$$PATH$$/4801.dat';

--
-- Data for Name: level5_v1; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level5_v1 (id_level, level, label_fr, label_en, level_up, version) FROM stdin;
\.
COPY public.level5_v1 (id_level, level, label_fr, label_en, level_up, version) FROM '$$PATH$$/4783.dat';

--
-- Data for Name: level6; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level6 (id_level, level, label_fr, label_en, level_up, version) FROM stdin;
\.
COPY public.level6 (id_level, level, label_fr, label_en, level_up, version) FROM '$$PATH$$/4802.dat';

--
-- Data for Name: level6_v1; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level6_v1 (id_level, level, label_fr, label_en, level_up, version) FROM stdin;
\.
COPY public.level6_v1 (id_level, level, label_fr, label_en, level_up, version) FROM '$$PATH$$/4784.dat';

--
-- Data for Name: level7; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level7 (id_level, level, label_fr, label_en, level_up, se, def_en, def_fr, version, valeur_seuil_en, valeur_seuil_fr, choix_seuil_en, choix_seuil_fr) FROM stdin;
\.
COPY public.level7 (id_level, level, label_fr, label_en, level_up, se, def_en, def_fr, version, valeur_seuil_en, valeur_seuil_fr, choix_seuil_en, choix_seuil_fr) FROM '$$PATH$$/4803.dat';

--
-- Data for Name: level7_v1; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.level7_v1 (id_level, level, label_fr, label_en, level_up, se, def_en, def_fr, version, valeur_seuil_en, valeur_seuil_fr, choix_seuil_en, choix_seuil_fr) FROM stdin;
\.
COPY public.level7_v1 (id_level, level, label_fr, label_en, level_up, se, def_en, def_fr, version, valeur_seuil_en, valeur_seuil_fr, choix_seuil_en, choix_seuil_fr) FROM '$$PATH$$/4785.dat';

--
-- Data for Name: manip; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.manip (id_site, date, id_plot, obs, notateur, id_manip, manip) FROM stdin;
\.
COPY public.manip (id_site, date, id_plot, obs, notateur, id_manip, manip) FROM '$$PATH$$/4786.dat';

--
-- Data for Name: releve; Type: TABLE DATA; Schema: public; Owner: dynuser
--

COPY public.releve (id_releve, num_arbre, dmh, qte, level, id_arbre, date) FROM stdin;
\.
COPY public.releve (id_releve, num_arbre, dmh, qte, level, id_arbre, date) FROM '$$PATH$$/4788.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys  FROM stdin;
\.
COPY public.spatial_ref_sys  FROM '$$PATH$$/4537.dat';

--
-- Name: arbre_id_arbre_seq; Type: SEQUENCE SET; Schema: public; Owner: dynuser
--

SELECT pg_catalog.setval('public.arbre_id_arbre_seq', 211, true);


--
-- Name: code_sp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dynuser
--

SELECT pg_catalog.setval('public.code_sp_id_seq', 1, false);


--
-- Name: espece_id_espece_seq; Type: SEQUENCE SET; Schema: public; Owner: dynuser
--

SELECT pg_catalog.setval('public.espece_id_espece_seq', 153, true);


--
-- Name: genre_id_genre_seq; Type: SEQUENCE SET; Schema: public; Owner: dynuser
--

SELECT pg_catalog.setval('public.genre_id_genre_seq', 52, true);


--
-- Name: level1_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: dynuser
--

SELECT pg_catalog.setval('public.level1_id_level_seq', 7, true);


--
-- Name: level2_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: dynuser
--

SELECT pg_catalog.setval('public.level2_id_level_seq', 1, false);


--
-- Name: manip_id_manip_seq; Type: SEQUENCE SET; Schema: public; Owner: dynuser
--

SELECT pg_catalog.setval('public.manip_id_manip_seq', 84, true);


--
-- Name: releve_id_releve_seq; Type: SEQUENCE SET; Schema: public; Owner: dynuser
--

SELECT pg_catalog.setval('public.releve_id_releve_seq', 278, true);


--
-- Name: arbre arbre_pkey; Type: CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.arbre
    ADD CONSTRAINT arbre_pkey PRIMARY KEY (uuid_arbre);


--
-- Name: manip manip_pkey; Type: CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.manip
    ADD CONSTRAINT manip_pkey PRIMARY KEY (uuid_manip);


--
-- Name: releve_cepee releve_cepee_pkey; Type: CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_pkey PRIMARY KEY (uuid_releve);


--
-- Name: releve releve_pkey; Type: CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_pkey PRIMARY KEY (uuid_releve);


--
-- Name: site site_pkey; Type: CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.site
    ADD CONSTRAINT site_pkey PRIMARY KEY (id_site);


--
-- Name: manip unik_manip; Type: CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.manip
    ADD CONSTRAINT unik_manip UNIQUE (notateur, id_site, manip);


--
-- Name: arbre arbre_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.arbre
    ADD CONSTRAINT arbre_pkey PRIMARY KEY (id_arbre);


--
-- Name: code_sp code_sp_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.code_sp
    ADD CONSTRAINT code_sp_pkey PRIMARY KEY (id);


--
-- Name: espece espece_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.espece
    ADD CONSTRAINT espece_pkey PRIMARY KEY (id_espece);


--
-- Name: genre genre_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.genre
    ADD CONSTRAINT genre_pkey PRIMARY KEY (id_genre);


--
-- Name: level1_v1 level1_id_level_key; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level1_v1
    ADD CONSTRAINT level1_id_level_key UNIQUE (id_level);


--
-- Name: level2_v1 level2_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level2_v1
    ADD CONSTRAINT level2_pkey PRIMARY KEY (id_level);


--
-- Name: level3_v1 level3_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level3_v1
    ADD CONSTRAINT level3_pkey PRIMARY KEY (id_level);


--
-- Name: level4_v1 level4_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level4_v1
    ADD CONSTRAINT level4_pkey PRIMARY KEY (id_level);


--
-- Name: level5_v1 level5_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level5_v1
    ADD CONSTRAINT level5_pkey PRIMARY KEY (id_level);


--
-- Name: level6_v1 level6_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level6_v1
    ADD CONSTRAINT level6_pkey PRIMARY KEY (id_level);


--
-- Name: level7_v1 level7_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.level7_v1
    ADD CONSTRAINT level7_pkey PRIMARY KEY (id_level);

ALTER TABLE public.level7_v1 CLUSTER ON level7_pkey;


--
-- Name: manip manip_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.manip
    ADD CONSTRAINT manip_pkey PRIMARY KEY (id_manip);


--
-- Name: releve releve_pkey; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_pkey PRIMARY KEY (id_releve);


--
-- Name: manip unik_manip; Type: CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.manip
    ADD CONSTRAINT unik_manip UNIQUE (id_plot, notateur, id_site, manip);


--
-- Name: arbre arbre_esp_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.arbre
    ADD CONSTRAINT arbre_esp_fkey FOREIGN KEY (esp) REFERENCES public.espece(id_espece);


--
-- Name: arbre arbre_genre_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.arbre
    ADD CONSTRAINT arbre_genre_fkey FOREIGN KEY (genre) REFERENCES public.genre(id_genre);


--
-- Name: arbre arbre_uuid_manip_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.arbre
    ADD CONSTRAINT arbre_uuid_manip_fkey FOREIGN KEY (uuid_manip) REFERENCES fraxpyr.manip(uuid_manip);


--
-- Name: brin brin_uuid_arbre_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.brin
    ADD CONSTRAINT brin_uuid_arbre_fkey FOREIGN KEY (uuid_arbre) REFERENCES fraxpyr.arbre(uuid_arbre);


--
-- Name: brin brin_uuid_manip_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.brin
    ADD CONSTRAINT brin_uuid_manip_fkey FOREIGN KEY (uuid_manip) REFERENCES fraxpyr.manip(uuid_manip);


--
-- Name: releve_cepee releve_cepee_level_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_level_fkey FOREIGN KEY (level) REFERENCES public.level1_v1(id_level);


--
-- Name: releve_cepee releve_cepee_level_fkey1; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_level_fkey1 FOREIGN KEY (level) REFERENCES public.level2_v1(id_level);


--
-- Name: releve_cepee releve_cepee_level_fkey2; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_level_fkey2 FOREIGN KEY (level) REFERENCES public.level3_v1(id_level);


--
-- Name: releve_cepee releve_cepee_level_fkey3; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_level_fkey3 FOREIGN KEY (level) REFERENCES public.level4_v1(id_level);


--
-- Name: releve_cepee releve_cepee_level_fkey4; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_level_fkey4 FOREIGN KEY (level) REFERENCES public.level5_v1(id_level);


--
-- Name: releve_cepee releve_cepee_level_fkey5; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_level_fkey5 FOREIGN KEY (level) REFERENCES public.level6_v1(id_level);


--
-- Name: releve_cepee releve_cepee_level_fkey6; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_level_fkey6 FOREIGN KEY (level) REFERENCES public.level7_v1(id_level);


--
-- Name: releve_cepee releve_cepee_uuid_arbre_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve_cepee
    ADD CONSTRAINT releve_cepee_uuid_arbre_fkey FOREIGN KEY (uuid_arbre) REFERENCES fraxpyr.arbre(uuid_arbre);


--
-- Name: releve releve_level_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_level_fkey FOREIGN KEY (level) REFERENCES public.level1_v1(id_level);


--
-- Name: releve releve_level_fkey1; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_level_fkey1 FOREIGN KEY (level) REFERENCES public.level2_v1(id_level);


--
-- Name: releve releve_level_fkey2; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_level_fkey2 FOREIGN KEY (level) REFERENCES public.level3_v1(id_level);


--
-- Name: releve releve_level_fkey3; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_level_fkey3 FOREIGN KEY (level) REFERENCES public.level4_v1(id_level);


--
-- Name: releve releve_level_fkey4; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_level_fkey4 FOREIGN KEY (level) REFERENCES public.level5_v1(id_level);


--
-- Name: releve releve_level_fkey5; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_level_fkey5 FOREIGN KEY (level) REFERENCES public.level6_v1(id_level);


--
-- Name: releve releve_level_fkey6; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_level_fkey6 FOREIGN KEY (level) REFERENCES public.level7_v1(id_level);


--
-- Name: releve releve_uuid_arbre_fkey; Type: FK CONSTRAINT; Schema: fraxpyr; Owner: dynuser
--

ALTER TABLE ONLY fraxpyr.releve
    ADD CONSTRAINT releve_uuid_arbre_fkey FOREIGN KEY (uuid_arbre) REFERENCES fraxpyr.arbre(uuid_arbre);


--
-- Name: arbre arbre_esp_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.arbre
    ADD CONSTRAINT arbre_esp_fkey FOREIGN KEY (esp) REFERENCES public.espece(id_espece);


--
-- Name: arbre arbre_genre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.arbre
    ADD CONSTRAINT arbre_genre_fkey FOREIGN KEY (genre) REFERENCES public.genre(id_genre);


--
-- Name: arbre arbre_id_manip_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.arbre
    ADD CONSTRAINT arbre_id_manip_fkey FOREIGN KEY (id_manip) REFERENCES public.manip(id_manip);


--
-- Name: espece espece_id_genre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.espece
    ADD CONSTRAINT espece_id_genre_fkey FOREIGN KEY (id_genre) REFERENCES public.genre(id_genre);


--
-- Name: releve releve_id_arbre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_id_arbre_fkey FOREIGN KEY (id_arbre) REFERENCES public.arbre(id_arbre);


--
-- Name: releve releve_level_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_level_fkey FOREIGN KEY (level) REFERENCES public.level1_v1(id_level);


--
-- Name: releve releve_level_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_level_fkey1 FOREIGN KEY (level) REFERENCES public.level2_v1(id_level);


--
-- Name: releve releve_level_fkey2; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_level_fkey2 FOREIGN KEY (level) REFERENCES public.level3_v1(id_level);


--
-- Name: releve releve_level_fkey3; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_level_fkey3 FOREIGN KEY (level) REFERENCES public.level4_v1(id_level);


--
-- Name: releve releve_level_fkey4; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_level_fkey4 FOREIGN KEY (level) REFERENCES public.level5_v1(id_level);


--
-- Name: releve releve_level_fkey5; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_level_fkey5 FOREIGN KEY (level) REFERENCES public.level6_v1(id_level);


--
-- Name: releve releve_level_fkey6; Type: FK CONSTRAINT; Schema: public; Owner: dynuser
--

ALTER TABLE ONLY public.releve
    ADD CONSTRAINT releve_level_fkey6 FOREIGN KEY (level) REFERENCES public.level7_v1(id_level);


--
-- Name: SCHEMA fraxpyr; Type: ACL; Schema: -; Owner: dynuser
--

GRANT USAGE ON SCHEMA fraxpyr TO dmh_fraxpyr_user;
GRANT USAGE ON SCHEMA fraxpyr TO dmh_fraxpyr_admin;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO dynuser;
GRANT USAGE ON SCHEMA public TO geo_dmh_user;
GRANT USAGE ON SCHEMA public TO geo_dmh_admin;


--
-- Name: TABLE espece; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.espece TO geo_dmh_admin;
GRANT SELECT ON TABLE public.espece TO geo_dmh_user;
GRANT SELECT ON TABLE public.espece TO dmh_fraxpyr_user;


--
-- Name: TABLE genre; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.genre TO geo_dmh_admin;
GRANT SELECT ON TABLE public.genre TO geo_dmh_user;
GRANT SELECT ON TABLE public.genre TO dmh_fraxpyr_user;


--
-- Name: TABLE level2_v1; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level2_v1 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level2_v1 TO geo_dmh_user;
GRANT SELECT ON TABLE public.level2_v1 TO dmh_fraxpyr_user;


--
-- Name: SEQUENCE level2_id_level_seq; Type: ACL; Schema: public; Owner: dynuser
--

GRANT ALL ON SEQUENCE public.level2_id_level_seq TO geo_dmh_admin;
GRANT SELECT ON SEQUENCE public.level2_id_level_seq TO dmh_fraxpyr_user;


--
-- Name: TABLE level3; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT ON TABLE public.level3 TO dmh_fraxpyr_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level3 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level3 TO geo_dmh_user;


--
-- Name: TABLE level3_v1; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level3_v1 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level3_v1 TO geo_dmh_user;
GRANT SELECT ON TABLE public.level3_v1 TO dmh_fraxpyr_user;


--
-- Name: TABLE arbre; Type: ACL; Schema: fraxpyr; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE fraxpyr.arbre TO dmh_fraxpyr_admin;
GRANT SELECT ON TABLE fraxpyr.arbre TO dmh_fraxpyr_user;


--
-- Name: TABLE brin; Type: ACL; Schema: fraxpyr; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE fraxpyr.brin TO dmh_fraxpyr_admin;
GRANT SELECT ON TABLE fraxpyr.brin TO dmh_fraxpyr_user;


--
-- Name: TABLE cepee; Type: ACL; Schema: fraxpyr; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE fraxpyr.cepee TO dmh_fraxpyr_admin;
GRANT SELECT ON TABLE fraxpyr.cepee TO dmh_fraxpyr_user;


--
-- Name: TABLE manip; Type: ACL; Schema: fraxpyr; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE fraxpyr.manip TO dmh_fraxpyr_admin;
GRANT SELECT ON TABLE fraxpyr.manip TO dmh_fraxpyr_user;


--
-- Name: TABLE releve; Type: ACL; Schema: fraxpyr; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE fraxpyr.releve TO dmh_fraxpyr_admin;
GRANT SELECT ON TABLE fraxpyr.releve TO dmh_fraxpyr_user;


--
-- Name: TABLE releve_cepee; Type: ACL; Schema: fraxpyr; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE fraxpyr.releve_cepee TO dmh_fraxpyr_admin;
GRANT SELECT ON TABLE fraxpyr.releve_cepee TO dmh_fraxpyr_user;


--
-- Name: TABLE site; Type: ACL; Schema: fraxpyr; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE fraxpyr.site TO dmh_fraxpyr_admin;
GRANT SELECT ON TABLE fraxpyr.site TO dmh_fraxpyr_user;


--
-- Name: TABLE arbre; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.arbre TO geo_dmh_admin;
GRANT SELECT ON TABLE public.arbre TO geo_dmh_user;
GRANT SELECT ON TABLE public.arbre TO dmh_fraxpyr_user;


--
-- Name: SEQUENCE arbre_id_arbre_seq; Type: ACL; Schema: public; Owner: dynuser
--

GRANT ALL ON SEQUENCE public.arbre_id_arbre_seq TO geo_dmh_admin;
GRANT SELECT ON SEQUENCE public.arbre_id_arbre_seq TO dmh_fraxpyr_user;


--
-- Name: TABLE code_sp; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.code_sp TO geo_dmh_admin;
GRANT SELECT ON TABLE public.code_sp TO geo_dmh_user;
GRANT SELECT ON TABLE public.code_sp TO dmh_fraxpyr_user;


--
-- Name: SEQUENCE code_sp_id_seq; Type: ACL; Schema: public; Owner: dynuser
--

GRANT ALL ON SEQUENCE public.code_sp_id_seq TO geo_dmh_admin;
GRANT SELECT ON SEQUENCE public.code_sp_id_seq TO dmh_fraxpyr_user;


--
-- Name: SEQUENCE espece_id_espece_seq; Type: ACL; Schema: public; Owner: dynuser
--

GRANT ALL ON SEQUENCE public.espece_id_espece_seq TO geo_dmh_admin;
GRANT SELECT ON SEQUENCE public.espece_id_espece_seq TO dmh_fraxpyr_user;


--
-- Name: SEQUENCE genre_id_genre_seq; Type: ACL; Schema: public; Owner: dynuser
--

GRANT ALL ON SEQUENCE public.genre_id_genre_seq TO geo_dmh_admin;
GRANT SELECT ON SEQUENCE public.genre_id_genre_seq TO dmh_fraxpyr_user;


--
-- Name: TABLE level1_v1; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level1_v1 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level1_v1 TO geo_dmh_user;
GRANT SELECT ON TABLE public.level1_v1 TO dmh_fraxpyr_user;


--
-- Name: SEQUENCE level1_id_level_seq; Type: ACL; Schema: public; Owner: dynuser
--

GRANT ALL ON SEQUENCE public.level1_id_level_seq TO geo_dmh_admin;
GRANT SELECT ON SEQUENCE public.level1_id_level_seq TO dmh_fraxpyr_user;


--
-- Name: TABLE level1; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT ON TABLE public.level1 TO dmh_fraxpyr_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level1 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level1 TO geo_dmh_user;


--
-- Name: TABLE level2; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT ON TABLE public.level2 TO dmh_fraxpyr_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level2 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level2 TO geo_dmh_user;


--
-- Name: TABLE level4; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT ON TABLE public.level4 TO dmh_fraxpyr_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level4 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level4 TO geo_dmh_user;


--
-- Name: TABLE level4_v1; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level4_v1 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level4_v1 TO geo_dmh_user;
GRANT SELECT ON TABLE public.level4_v1 TO dmh_fraxpyr_user;


--
-- Name: TABLE level5; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT ON TABLE public.level5 TO dmh_fraxpyr_user;
GRANT SELECT ON TABLE public.level5 TO geo_dmh_user;


--
-- Name: TABLE level5_v1; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level5_v1 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level5_v1 TO geo_dmh_user;
GRANT SELECT ON TABLE public.level5_v1 TO dmh_fraxpyr_user;


--
-- Name: TABLE level6; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT ON TABLE public.level6 TO dmh_fraxpyr_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level6 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level6 TO geo_dmh_user;


--
-- Name: TABLE level6_v1; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level6_v1 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level6_v1 TO geo_dmh_user;
GRANT SELECT ON TABLE public.level6_v1 TO dmh_fraxpyr_user;


--
-- Name: TABLE level7; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT ON TABLE public.level7 TO dmh_fraxpyr_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level7 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level7 TO geo_dmh_user;


--
-- Name: TABLE level7_v1; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.level7_v1 TO geo_dmh_admin;
GRANT SELECT ON TABLE public.level7_v1 TO geo_dmh_user;
GRANT SELECT ON TABLE public.level7_v1 TO dmh_fraxpyr_user;


--
-- Name: TABLE manip; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.manip TO geo_dmh_admin;
GRANT SELECT ON TABLE public.manip TO geo_dmh_user;
GRANT SELECT ON TABLE public.manip TO dmh_fraxpyr_user;


--
-- Name: SEQUENCE manip_id_manip_seq; Type: ACL; Schema: public; Owner: dynuser
--

GRANT ALL ON SEQUENCE public.manip_id_manip_seq TO geo_dmh_admin;
GRANT SELECT ON SEQUENCE public.manip_id_manip_seq TO dmh_fraxpyr_user;


--
-- Name: TABLE releve; Type: ACL; Schema: public; Owner: dynuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.releve TO geo_dmh_admin;
GRANT SELECT ON TABLE public.releve TO geo_dmh_user;
GRANT SELECT ON TABLE public.releve TO dmh_fraxpyr_user;


--
-- Name: SEQUENCE releve_id_releve_seq; Type: ACL; Schema: public; Owner: dynuser
--

GRANT ALL ON SEQUENCE public.releve_id_releve_seq TO geo_dmh_admin;
GRANT SELECT ON SEQUENCE public.releve_id_releve_seq TO dmh_fraxpyr_user;


--
-- PostgreSQL database dump complete
--

