<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />
	<script language="javascript" type="text/javascript">
		function verif(){
            if (window.confirm('Ce DMH sera effacé / Trem will be deleted')) {
               return true;
            } else {
               return false;
            }
	}
	</script>

</head>

<body>
<? $lang=$_GET[lang]; ?>

<div id="global">
<div id="centralpres">
<? if ($lang=='fr'){ ?><a href="releve.php?lang=<?php echo $lang; ?>" class="rien">Reprendre la saisie</a> <? } else { ?>  <a href="releve.php?lang=<?php echo $lang; ?>" class="rien">Back</a> <? } ?>

<br/><br/>
&nbsp;&nbsp;&nbsp;<fieldset><b><? if ($lang=='fr'){echo "Arbre en cours";}else{echo "Tree currently observed";} ?></b> :<span style="color:red;"> <?php echo $_SESSION['nom_arbre']; ?></span></fieldset><br/><br/>

<?php
require 'connect_db.inc.php'; 
$uuid_arbre = $_SESSION[uuid_arbre];
$uuid_brin = $_SESSION[uuid_brin];
$sql = "SELECT * FROM fraxpyr.releve WHERE uuid_brin='$uuid_brin'";
$res = pg_query($sql);
$count = pg_num_rows($res);

if ($lang=='fr'){echo 'Il y a '.$count.' dendromicrohabitat(s) enregistré(s) pour ce brin.<br/><br/>';}
else{echo $count.' trem(s) currently recorded for this strand.<br/><br/>'; }

echo '<ul>';
while ($data=pg_fetch_array($res)){

	$table_level='level'.$data['level'];
	$level=$data['dmh'];
	$niv3=substr($level,0,4); 
	$sql_level = "SELECT label_fr,label_en FROM $table_level WHERE level='$level' AND version='v2'";
	$res_level=pg_query($sql_level);
	$data2=pg_fetch_array($res_level);
	
	$sql_level3 = "SELECT label_fr,label_en FROM level3 WHERE level='$niv3' AND version='v2'";
	$res_level3=pg_query($sql_level3);
	$data3=pg_fetch_array($res_level3);
	
	 if ($lang=='fr'){echo "<li><form action=\"effacer_releve.php?releve=".$data['uuid_releve']."&lang=".$lang."\" method=\"post\" onSubmit=\"return verif();window.location.reload(true);\">".$data['qte']." ".$data3['label_fr']." (".$data2['label_fr'].") &nbsp;<input type=\"image\" src=\"./trash.png\" align=\"absmiddle\"></form></li><br/>";}
	 else{
	 echo "	<li><form action=\"effacer_releve.php?releve=".$data['uuid_releve']."&lang=".$lang."\" method=\"post\" onSubmit=\"return verif();window.location.reload(true);\">".$data['qte']." ".$data3['label_en']." (".$data2['label_en'].") &nbsp;<input type=\"image\" src=\"./trash.png\" align=\"absmiddle\"></form></li><br/>";} 
	
}
echo '</ul>';
?>

</center>
<br/>
</div>
</div>
<?php include('pdp.php');  ?>  

</body>



