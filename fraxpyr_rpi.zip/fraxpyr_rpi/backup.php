<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />


</head>

<body>
<? $lang=$_GET[lang]; ?>
<div id="global">
<div id="centralpres">
<? if ($lang=='fr'){ ?><a href="menu_manip.php?lang=<?php echo $lang; ?>" class="rien">Menu principal</a> <? } else { ?>  <a href="menu_manip.php?lang=<?php echo $lang; ?>" class="rien">Home</a> <? } ?>
<br/><br/>
Vous DEVEZ télécharger les différentes tables de la base.

(Pensez à les copier sur la tablette et/ou une clé USB ...)<br/><br/>
<? include "connect_db.inc.php";
   session_start();
   
   $bckp_manip = pg_copy_to($connexion, 'fraxpyr.manip','|');
   $bckp_arbre = pg_copy_to($connexion, 'fraxpyr.arbre','|');
   $bckp_brin = pg_copy_to($connexion, 'fraxpyr.brin','|');
   $bckp_cepee = pg_copy_to($connexion, 'fraxpyr.cepee','|');
   $bckp_releve = pg_copy_to($connexion, 'fraxpyr.releve','|');
   $bckp_releve_cepee = pg_copy_to($connexion, 'fraxpyr.releve_cepee','|');
 $date=date('Ymd-hi');   
   // Sauvegarde des manips
   $fp = fopen('bckp/manip'.$date.'.csv', 'w');
   for($i=0;$i<sizeof($bckp_manip);$i++) 
    {
    	$fields= $bckp_manip[$i]; 
    	fwrite($fp, $fields);
    } 
   fclose($fp);
   
   // Sauvegarde des arbres
   $fp = fopen('bckp/arbre'.$date.'.csv', 'w');
   for($i=0;$i<sizeof($bckp_arbre);$i++) 
    {
    	$fields= $bckp_arbre[$i]; 
    	fwrite($fp, $fields);
    } 
   fclose($fp);

   // Sauvegarde des cépées
   $fp = fopen('bckp/cepee'.$date.'.csv', 'w');
   for($i=0;$i<sizeof($bckp_cepee);$i++) 
    {
    	$fields= $bckp_cepee[$i]; 
    	fwrite($fp, $fields);
    } 
   fclose($fp);

   // Sauvegarde des brins
   $fp = fopen('bckp/brin'.$date.'.csv', 'w');
   for($i=0;$i<sizeof($bckp_brin);$i++) 
    {
    	$fields= $bckp_brin[$i]; 
    	fwrite($fp, $fields);
    } 
   fclose($fp);
   
   // Sauvegarde des relevés
   $fp = fopen('bckp/releve'.$date.'.csv', 'w');
   for($i=0;$i<sizeof($bckp_releve);$i++) 
    {
    	$fields= $bckp_releve[$i]; 
    	fwrite($fp, $fields);
    } 
   fclose($fp);

   // Sauvegarde des relevés cépée
   $fp = fopen('bckp/releve_cepee'.$date.'.csv', 'w');
   for($i=0;$i<sizeof($bckp_releve_cepee);$i++) 
    {
    	$fields= $bckp_releve_cepee[$i]; 
    	fwrite($fp, $fields);
    } 
   fclose($fp);
   

   echo '<a href="bckp/manip'.$date.'.csv" class="rien">Manips</a><br/>';
   echo '<a href="bckp/arbre'.$date.'.csv" class="rien">Arbres</a><br/>';
   echo '<a href="bckp/cepee'.$date.'.csv" class="rien">Cépées</a><br/>';
   echo '<a href="bckp/brin'.$date.'.csv" class="rien">Brins</a><br/>';
   echo '<a href="bckp/releve'.$date.'.csv" class="rien">Relevés</a><br/>';
   echo '<a href="bckp/releve_cepee'.$date.'.csv" class="rien">Relevés cépées</a><br/>';
   
  ?>
 <br/><br/><br/>
</div>
</div>
<?php include('pdp.php');  ?>  

</body>
