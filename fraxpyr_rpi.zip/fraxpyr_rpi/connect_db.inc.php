<?php
// paramètres de connexion PGSQL à la base geo_dmh rpi

$serveur="172.24.1.1"; // adresse du serveur de base de données
$port='5432'; // port du serveur de base de données (5432 par défaut pour postgreSQL)
$base="geo_dmh"; // nom de la base
$user="dynuser"; // identifiant de connexion
$mdp="dynuser"; // mot de passe

$connexion = pg_connect("host=$serveur port=$port dbname=$base user=$user password=$mdp");

?>
