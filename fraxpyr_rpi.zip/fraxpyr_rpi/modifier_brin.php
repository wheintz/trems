<? $lang=$_GET[lang]; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />


</head>

<body>

<div id="global">
<div id="centralpres">
<?php
session_start();
require 'connect_db.inc.php'; 
$mode=$_GET[mode];


if ($lang=='fr'){echo '<a href="index.php?mode=reset&lang='.$lang.'" class="rien">Changer manip</a> | ';}else{echo '<a href="index.php?mode=reset&lang='.$lang.'" class="rien">Experience change</a> | ';}  

if ($lang=='fr'){echo '<a href="find_arbre.php?lang='.$lang.'" class="rien">Liste arbres</a> | ';}else{echo '<a href="find_arbre.php?lang='.$lang.'" class="rien">Tree already recorded</a> | ';} 

if ($_SESSION['uuid_cepee'] != '') {
if ($lang=='fr'){echo '<a href="menu_cepee.php?lang='.$lang.'" class="rien">Menu cépée</a> | ';}else{echo '<a href="menu_cepee.php?lang='.$lang.'" class="rien">Shrub home</a> | ';} 
}
if ($lang=='fr'){echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Accueil manip</a><br/><br/>';}else{echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Experience home</a><br/><br/>';} 

if ($mode == 'valid') { /* ===================================== Validation du formulaire ====================================== */

$uuid_brin=$_GET['brin'];

$uuid_manip=$_SESSION['uuid_manip'];
$uuid_arbre=$_SESSION['uuid_arbre'];

$dbh = $_POST['dbh'];
$num_brin = $_POST['num_brin'];	
$forme = $_POST['forme'];
$gestion = $_POST['gestion'];
$dia_br = $_POST['dia_br'];

$photo = $_POST['photo'];
$htot = $_POST['htot'];
$hfut = $_POST['hfut'];
$dhref = $_POST['dhref'];

$nb_br20_fut = $_POST['nb_br20_fut'];
$nb_br20sup_fut = $_POST['nb_br20sup_fut'];
$nb_br20_tete = $_POST['nb_br20_tete'];
$nb_br20sup_tete = $_POST['nb_br20sup_tete'];

$commentaire = $_POST['commentaire'];
$nom_arbre = $_POST['nom_arbre'];

$num_arbre=$genre.'-'.$esp;

$requete = "UPDATE fraxpyr.brin SET num_brin='$num_brin', dbh='$dbh',forme='$forme',gestion='$gestion',dia_br='$dia_br', htot='$htot',photo='$photo',hfut='$hfut',
dhref='$dhref', nb_br20_fut='$nb_br20_fut', nb_br20sup_fut='$nb_br20sup_fut', nb_br20_tete='$nb_br20_tete', nb_br20sup_tete='$nb_br20sup_tete', commentaire='$commentaire' WHERE uuid_brin='$uuid_brin'";
	
	$result = pg_query($requete); 
	$data = pg_fetch_array($result);
	if( $result == FALSE ) {		
		echo "Une erreur s'est produite ...<br/>";
		echo '<!--'.$requete.'-->';
	} else {
		session_start();
		unset($_SESSION['uuid_brin']);
		$_SESSION['uuid_brin'] = $uuid_brin;
		$_SESSION['num_brin'] = $num_brin;
	
	if ($lang=='fr'){echo "<b>Le brin <span style=\"color:red;\"><i>".$num_brin."</i></span> a bien été modifié, vous pouvez <a class=\"rien\" href=\"releve.php?lang=".$lang."\">commencer la saisie de micro-habitats</a>.</b><br/><br/>";}
	else {echo "<b>Strand <span style=\"color:red;\"><i>".$num_brin."</i></span> updated, you can start <a class=\"rien\" href=\"releve.php?lang=".$lang."\">recording trems</a>.</b><br/><br/>";}	
	
	}		


} else {  /* ===================================== Remplissage du formulaire ====================================== */

   $uuid_manip = $_SESSION['uuid_manip'];
   $uuid_brin = $_GET['brin'];
  
$sql = "SELECT * FROM fraxpyr.brin WHERE uuid_manip='$uuid_manip' AND uuid_brin='$uuid_brin'";
$res = pg_query($sql); 
$data = pg_fetch_array($res); ?>
 
<form action="modifier_brin.php?mode=valid&lang=<? echo $lang; ?>&brin=<? echo $uuid_brin; ?>" method="post"> 


<b>Numéro ou nom du brin </b><br/><input type="text" name="num_brin" id="num_brin" value="<? echo $data['num_brin']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';"><br/><br/>

<b>DBH </b><br/><input type="text" name="dbh" id="dbh" value="<? echo $data['dbh']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<b>Diamètre à mi-hauteur </b><br/><input type="text" name="dhref" id="dhref" value="<? echo $data['dhref']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>


<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Forme';}else{echo 'Shape';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="forme" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['forme'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['forme'] == 'libre'){echo 'SELECTED';} ?> value="libre">Libre</option>
<option <? if ($data['forme'] == 'têtard'){echo 'SELECTED';} ?> value="têtard">Têtard</option>
<option <? if ($data['forme'] == 'émondé'){echo 'SELECTED';} ?> value="émondé">Émondé</option>
<option <? if ($data['forme'] == 'cépée'){echo 'SELECTED';} ?> value="cépée">Cépée</option>
<option <? if ($data['forme'] == 'coupe ponctuelle'){echo 'SELECTED';} ?> value="coupe ponctuelle">Coupe ponctuelle</option>
</select><br/><br/>

<? } else { ?>
<select name="forme" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['forme'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['forme'] == 'libre'){echo 'SELECTED';} ?> value="libre">Free</option>
<option <? if ($data['forme'] == 'têtard'){echo 'SELECTED';} ?> value="têtard">Têtard</option>
<option <? if ($data['forme'] == 'émondé'){echo 'SELECTED';} ?> value="émondé">Trimmed</option>
<option <? if ($data['forme'] == 'cépée'){echo 'SELECTED';} ?> value="cépée">Shrub</option>
<option <? if ($data['forme'] == 'coupe ponctuelle'){echo 'SELECTED';} ?> value="coupe ponctuelle">Ponctual cut</option>
</select><br/><br/>
<? } ?>


<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Sévérité de la gestion';}else{echo 'Management';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="gestion" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['gestion'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['gestion'] == '0'){echo 'SELECTED';} ?> value="0">Aucune</option>
<option <? if ($data['gestion'] == '1'){echo 'SELECTED';} ?> value="1">Faible</option>
<option <? if ($data['gestion'] == '2'){echo 'SELECTED';} ?> value="2">Forte</option>
</select><br/><br/>

<? } else { ?>
<select name="gestion" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['gestion'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['gestion'] == '0'){echo 'SELECTED';} ?> value="0">None</option>
<option <? if ($data['gestion'] == '1'){echo 'SELECTED';} ?> value="1">Low</option>
<option <? if ($data['gestion'] == '2'){echo 'SELECTED';} ?> value="2">High</option>
</select><br/><br/>
<? } ?>

<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Diamètre branches dernière coupe visible';}else{echo 'Last cut Branch diameter';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="dia_br" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['dia_br'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['dia_br'] == '< 5cm'){echo 'SELECTED';} ?> value="< 5cm">< 5cm</option>
<option <? if ($data['dia_br'] == '5-10cm'){echo 'SELECTED';} ?> value="5-10cm">5-10cm</option>
<option <? if ($data['dia_br'] == '10-20cm'){echo 'SELECTED';} ?> value="10-20cm">10-20cm</option>
<option <? if ($data['dia_br'] == '> 20cm'){echo 'SELECTED';} ?> value="> 20cm">> 20cm</option>
</select><br/><br/>

<? } else { ?>
<select name="dia_br" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['dia_br'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['dia_br'] == '< 5cm'){echo 'SELECTED';} ?> value="< 5cm">< 5cm</option>
<option <? if ($data['dia_br'] == '5-10cm'){echo 'SELECTED';} ?> value="5-10cm">5-10cm</option>
<option <? if ($data['dia_br'] == '10-20cm'){echo 'SELECTED';} ?> value="10-20cm">10-20cm</option>
<option <? if ($data['dia_br'] == '> 20cm'){echo 'SELECTED';} ?> value="> 20cm">> 20cm</option>
</select><br/><br/>
<? } ?>


<?php if ($lang=='' OR $lang=='fr'){echo '<b>Hauteur totale';}else{echo '<b>Tree height </b>';} ?><br/><input type="text" name="htot" class="rech" value="<? echo $data['htot']; ?>" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Hauteur du fut';}else{echo '<b>Bole height </b>';} ?><br/><input type="text" name="hfut" class="rech" value="<? echo $data['hfut']; ?>" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nb de branches (10-20cm) sur le fût';}else{echo '<b>Nb branches 10-20 trunk </b>';} ?><br/><input type="text" name="nb_br20_fut" class="rech" value="<? echo $data['nb_br20_fut']; ?>" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nb de branches (>20cm) sur le fût';}else{echo '<b>Nb branches >20 trunk </b>';} ?><br/><input type="text" name="nb_br20sup_fut" value="<? echo $data['nb_br20sup_fut']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nb de branches/brins (10-20cm) sur la tête';}else{echo '<b>Nb branches 10-20 head </b>';} ?><br/><input type="text" name="nb_br20_tete" value="<? echo $data['nb_br20_tete']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nb de branches/brins (>20cm) sur la tête';}else{echo '<b>Nb branches >20 head </b>';} ?><br/><input type="text" name="nb_br20sup_tete" value="<? echo $data['nb_br20sup_tete']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Photos';}else{echo '<b>Pictures</b>';} ?><br/><input type="text" name="photo" class="rech" value="<? echo $data['photo']; ?>" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Commentaire';}else{echo '<b>Comment</b>';} ?><br/><textarea name="commentaire" class="texta" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><? echo $data['commentaire']; ?></textarea><br/><br/>

<input type="image" src="ok.png" align="absmiddle" title="Ok"> 

</form>

<?
}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



