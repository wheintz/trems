<? $lang=$_GET[lang]; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli TREMS</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />
	<script language="javascript" type="application/javascript">
	function Affiche(nom){
		fichier = document.getElementById(nom)
		if (fichier.style.display == "none" ){
			fichier.style.display = "inline"
		}
		else {
			fichier.style.display = "none"
		}
	}
	function Ferme(nom){
		fichier = document.getElementById(nom)
			if (fichier.style.display == "inline" ){
			fichier.style.display = "none"
			}
		}
	</script>

</head>

<body>
<div id="global">
<div id="centralpres">
<?php
session_start();
require 'connect_db.inc.php'; 
$mode=$_GET[mode];


if ($lang=='fr'){echo '<a href="index.php?reset=reset&lang='.$lang.'" class="rien">Changer manip</a> | ';}else{echo '<a href="index.php?reset=reset&lang='.$lang.'" class="rien">Experience change</a> | ';} 

if ($lang=='fr'){echo '<a href="find_arbre.php?lang='.$lang.'" class="rien">Liste arbres </a> | ';}else{echo '<a href="find_arbre.php?lang='.$lang.'" class="rien">Tree already recorded</a> | ';} 

if ($lang=='fr'){echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Accueil manip</a><br/><br/>';}else{echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Experience home</a><br/><br/>';} 

if ($mode == 'valid') { /* ===================================== Validation du formulaire ====================================== */



$uuid_manip=$_SESSION['uuid_manip'];
$nom_arbre = $_POST['nom_arbre'];
$genre = $_POST['genre'];
$esp = $_POST['esp'];
$lon = $_POST['lon'];
$lat = $_POST['lat'];
$morpho = $_POST['morpho'];	
$localisation = $_POST['localisation'];
$photo = $_POST['photo'];
$commentaire = $_POST['commentaire'];


$num_arbre=$gestion.'-'.$dbh;

$requete = "INSERT INTO fraxpyr.arbre (nom_arbre,genre,esp,morpho,localisation,commentaire,photo,lon,lat,uuid_arbre,uuid_manip) VALUES ('$nom_arbre','$genre','$esp','$morpho','$localisation','$commentaire','$photo','$lon','$lat',uuid_generate_v4(),'$uuid_manip') RETURNING nom_arbre,uuid_arbre";
	
	$result = pg_query($requete); 
	$data = pg_fetch_array($result);
	if( $result == FALSE ) {		
		echo "Une erreur s'est produite ...<br/>";
		echo '<!--'.$requete.'-->';
	} else {
		session_start();
		unset($_SESSION['uuid_arbre']);unset($_SESSION['nom_arbre']); unset($_SESSION['uuid_cepee']); unset($_SESSION['uuid_brin']); unset($_SESSION['num_brin']);
		$_SESSION['uuid_arbre'] = $data['uuid_arbre'];
		$_SESSION['nom_arbre'] = $nom_arbre;
		
		
	if ($morpho == 'tronc unique'){
	
		if ($lang=='fr'){echo "<b>L'arbre <span style=\"color:red;\"><i>".$nom_arbre."</i></span> a bien été enregistré, vous pouvez <a class=\"rien\" href=\"brin.php?lang=".$lang."\">décrire ses caractéristiques</a>.</b><br/><br/>";}
		else {echo "<b>Tree <span style=\"color:red;\"><i>".$nom_arbre."</i></span> recorded, you can start <a class=\"rien\" href=\"brin.php?lang=".$lang."\">describing it</a>.</b><br/><br/>";}		
	
	} else {
	
		if ($lang=='fr'){echo "<b>L'arbre <span style=\"color:red;\"><i>".$nom_arbre."</i></span> a bien été enregistré, vous pouvez <a class=\"rien\" href=\"cepee.php?lang=".$lang."\">caractériser la cépée</a>.</b><br/><br/>";}
		else {echo "<b>Tree <span style=\"color:red;\"><i>".$nom_arbre."</i></span> recorded, you can start <a class=\"rien\" href=\"cepee.php?lang=".$lang."\">describing shrub</a>.</b><br/><br/>";}
	
	}
		
		
    }	

} else {  /* ===================================== Remplissage du formulaire ====================================== */

if ($_GET['reset'] == 'reset'){ unset($_SESSION['uuid_arbre']);unset($_SESSION['nom_arbre']); unset($_SESSION['uuid_cepee']); unset($_SESSION['uuid_brin']); unset($_SESSION['num_brin']);}

?>


<form action="arbre.php?mode=valid&lang=<? echo $lang; ?>" method="post"> 



<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Genre';}else{echo 'Genus';} ?></b><br/>

<select name="genre" onclick="this.style.backgroundColor='#DFF4B9'" onchange="window.location='arbre.php?lang=<?php echo $lang; ?>&genre='+this.value;">

                                <?
                                $sql = "SELECT DISTINCT id_genre, nom FROM genre ORDER BY nom";
                                $resultat = pg_query($sql);
                                if ($resultat === false) {
                                        echo "Erreur de connexion à la table des genres";
                                } else {
                                	$id_genre=$_GET[genre];
					if ($id_genre==''){echo '<option SELECTED value="">---</option>';}
                                        while ($ligne=pg_fetch_assoc($resultat)) {					
					if ($ligne['id_genre'] == $id_genre || $ligne['id_genre'] =='13'){$selected='SELECTED';}else{$selected='';}
                                        echo '<option '.$selected.' value="'.$ligne['id_genre'].'">'.$ligne['nom'].'</option>';
                                        }
                                }?>

</select>


<br/><br/>
<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Espèce';}else{echo 'Species';} ?></b><br/>

<select name="esp" onclick="this.style.backgroundColor='#DFF4B9'">

                                <?
                                $id_genre=$_GET[genre];
                                if ($id_genre == ''){$sql2 = "SELECT DISTINCT id_espece, nom FROM espece ORDER BY nom";} else 
                                {$sql2 = "SELECT DISTINCT id_espece, nom FROM espece WHERE id_genre='$id_genre' ORDER BY nom";}
                                $resultat2 = pg_query($sql2);
                                if ($resultat2 === false) {
                                        echo "Erreur de connexion à la table des espèces";
                                } else {
                                        while ($ligne2=pg_fetch_assoc($resultat2)) {
					if ($ligne2['id_espece'] == '24'){$selected='SELECTED';}else{$selected='';}
                                        echo '<option '.$selected.' value="'.$ligne2['id_espece'].'">'.$ligne2['nom'].'</option>';
                                        }
                                }?>

</select>
<br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nom de l\'arbre';}else{echo '<b>Tree name</b>';} ?><br/><input type="text" name="nom_arbre" class="rech" onclick="this.style.backgroundColor='#DFF4B9';"><br/><br/>

<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Morphologie';}else{echo 'Morphology';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="morpho" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="tronc unique">Tronc unique</option>
<option value="cépée">Cépée</option>
</select><br/><br/>

<? } else { ?>
<select name="morpho" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="tronc unique">Single trunk</option>
<option value="cépée">Shrub</option>
</select><br/><br/>
<? } ?>



<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Localisation';}else{echo 'Location';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="localisation" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="isolé">Isolé</option>
<option value="haie">Haie</option>
<option value="bosquet">Bosquet</option>
<option value="ripisylve">Ripisylve</option>
<option value="forêt">Forêt</option>
<option value="lisière">Lisière</option>
</select><br/><br/>

<? } else { ?>
<select name="localisation" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="isolé">Isolated</option>
<option value="haie">Hedge</option>
<option value="bosquet">Grove</option>
<option value="ripisylve">Riparian forest</option>
<option value="forêt">Forest</option>
<option value="lisière">Edge</option>
</select><br/><br/>
<? } ?>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Photos';}else{echo '<b>Pictures</b>';} ?><br/><input type="text" name="photo" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Longitude';}else{echo '<b>Long</b>';} ?><br/><input type="text" name="lon" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Latitude';}else{echo '<b>Lat</b>';} ?><br/><input type="text" name="lat" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Commentaire';}else{echo '<b>Comment</b>';} ?><br/><textarea name="commentaire" class="texta" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"></textarea><br/><br/>

<input type="image" src="ok.png" align="absmiddle" title="Ok"> 

</form>

<?
}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



