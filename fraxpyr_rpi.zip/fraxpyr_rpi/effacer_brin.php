<? include "connect_db.inc.php";
   session_start();
   if ($_GET['brin'] == $_SESSION['uuid_brin']){ 
   	if ($_GET[lang]=='fr'){echo "<script>alert(\"Vous ne pouvez pas effacer le brin en cours ! \")</script>";}
   	else {echo "<script>alert(\"You cannot delete the strand currently observed \")</script>";}
	print "<script>history.back(); </script>";
	exit();
   	
   	} else {
   
   	$uuid_brin = $_GET['brin'];
	$verif = "SELECT * FROM fraxpyr.releve WHERE uuid_brin='$uuid_brin'";
	$res = pg_query($verif);
	if (pg_num_rows($res)>0){
		if ($_GET[lang]=='fr') {echo "<script>alert(\"Des relevés existent pour ce brin, merci de les supprimer préalablement \")</script>";}
   		else {echo "<script>alert(\"Trems are linked to this strand, delete them before \")</script>";}
		print "<script>history.back(); </script>";
	
	} else {
   	
   	$sql="DELETE FROM fraxpyr.brin WHERE uuid_brin='".$_GET['brin']."'";
   	pg_query($sql);
   
   	echo "<script>alert(\"Ok \")</script>";
   	header('location:find_brin.php?lang='.$_GET['lang'].'');
   	}
   }	
   
  ?>
