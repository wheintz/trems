<?php
session_cache_limiter('private, must-revalidate');
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />

</head>

<body>
<div id="global">
<div id="centralpres">
<?php
require 'connect_db.inc.php'; 
$lang=$_GET[lang]; 
$num_arbre = $_SESSION['nom_arbre'];
$uuid_arbre = $_SESSION['uuid_arbre'];
$uuid_cepee = $_SESSION['uuid_cepee'];

echo "<b>Pour l'arbre ".$num_arbre." : </b><br/><br/>";

foreach ($_POST as $dmh => $qte) {
    //echo "DMH: $dmh; Qté: $qte<br />\n";
    
    if($dmh!='submit' && $qte!='0'){
    
    if (strlen($dmh)=='1'){$l='1';}
    if (strlen($dmh)=='3'){$l='2';}
    if (strlen($dmh)=='4'){$l='3';}
    if (strlen($dmh)=='5'){$l='4';}
    if (strlen($dmh)=='6'){$l='5';}
    if (strlen($dmh)=='7'){$l='6';}
    if (strlen($dmh)=='8'){$l='7';}
    
    $req = "INSERT INTO fraxpyr.releve_cepee (num_arbre,level,dmh,qte,uuid_releve,uuid_arbre,uuid_cepee) VALUES ('$num_arbre','$l','$dmh','$qte',uuid_generate_v4(),'$uuid_arbre','$uuid_cepee')";
			$res = pg_query($req); 
				if( $res == FALSE ) {		
					echo "Une erreur s'est produite ...<br/>";
					echo '<!--'.$req.'-->';
				} else {
					if ($lang=='fr'){ echo "<b>".$qte."</b> \"".$dmh."\"</b> enregistré(s)</b><br/><br/>";}
					else {echo "<b>".$qte."</b> \"".$dmh."\"</b> recorded</b><br/><br/>";}				
				}
	}
}
echo  '<a href="releve_cepee.php?lang='.$lang.'"><img border=0 src="home.png" align="absmiddle" title="Revenir à la saisie"></a>';  
    


?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



