<? include "connect_db.inc.php";
   session_start();
   if ($_GET['arbre'] == $_SESSION['uuid_arbre']){ 
   	if ($_GET[lang]=='fr'){echo "<script>alert(\"Vous ne pouvez pas effacer l'arbre en cours ! \")</script>";}
   	else {echo "<script>alert(\"You cannot delete the tree currently observed \")</script>";}
	print "<script>history.back(); </script>";
	exit();
   	
   	} else {
   
   	$uuid_arbre = $_GET['arbre'];
	$verif = "SELECT * FROM fraxpyr.releve WHERE uuid_arbre='$uuid_arbre'";
	$res = pg_query($verif);
	if (pg_num_rows($res)>0){
		if ($_GET[lang]=='fr') {echo "<script>alert(\"Des relevés existent pour cet arbre, merci de les supprimer préalablement \")</script>";}
   		else {echo "<script>alert(\"Trems are linked to this tree, delete them before \")</script>";}
		print "<script>history.back(); </script>";
	
	} else {
   	
   	$sql="DELETE FROM fraxpyr.arbre WHERE uuid_arbre='".$_GET['arbre']."'";
   	pg_query($sql);
   
   	echo "<script>alert(\"Ok \")</script>";
   	header('location:find_arbre.php?lang='.$_GET['lang'].'');
   	}
   }	
   
  ?>
