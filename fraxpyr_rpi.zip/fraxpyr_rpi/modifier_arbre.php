<? $lang=$_GET[lang]; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />


</head>

<body>

<div id="global">
<div id="centralpres">
<?php
session_start();
require 'connect_db.inc.php'; 
$mode=$_GET[mode];


if ($lang=='fr'){echo '<a href="index.php?mode=reset&lang='.$lang.'" class="rien">Changer manip</a> | ';}else{echo '<a href="index.php?mode=reset&lang='.$lang.'" class="rien">Experience change</a> | ';}  

if ($lang=='fr'){echo '<a href="find_arbre.php?lang='.$lang.'" class="rien">Liste arbres</a> | ';}else{echo '<a href="find_arbre.php?lang='.$lang.'" class="rien">Tree already recorded</a> | ';} 

if ($lang=='fr'){echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Accueil manip</a><br/><br/>';}else{echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Experience home</a><br/><br/>';} 

if ($mode == 'valid') { /* ===================================== Validation du formulaire ====================================== */

$uuid_arbre=$_GET['arbre'];

$uuid_manip=$_SESSION['uuid_manip'];

$genre = $_POST['genre'];
$esp = $_POST['esp'];
$lon = $_POST['lon'];
$lat = $_POST['lat'];

$morpho = $_POST['morpho'];	

$photo = $_POST['photo'];

$localisation = $_POST['localisation'];

$commentaire = $_POST['commentaire'];
$nom_arbre = $_POST['nom_arbre'];

$num_arbre=$genre.'-'.$esp;

$requete = "UPDATE fraxpyr.arbre SET nom_arbre='$nom_arbre', num_arbre='$num_arbre', genre='$genre',esp='$esp',morpho='$morpho',localisation='$localisation', commentaire='$commentaire',photo='$photo',lon='$lon',
lat='$lat' WHERE uuid_arbre='$uuid_arbre'";
	
	$result = pg_query($requete); 
	if( $result == FALSE ) {		
		echo "Une erreur s'est produite ...<br/>";
		echo '<!--'.$requete.'-->';
	} else {
		session_start();
		unset($_SESSION['uuid_arbre']);unset($_SESSION['nom_arbre']); unset($_SESSION['uuid_cepee']); unset($_SESSION['uuid_brin']); unset($_SESSION['num_brin']);
		$_SESSION['uuid_arbre'] = $uuid_arbre;
		$_SESSION['nom_arbre'] = $nom_arbre;
	
	if ($morpho == 'tronc unique'){

$sql = "SELECT * FROM fraxpyr.brin WHERE uuid_manip='$uuid_manip' AND uuid_arbre='$uuid_arbre'";
$res = pg_query($sql); 
$count=pg_num_rows($res);
$data = pg_fetch_array($res);
	
		if ($count =='0'){
			if ($lang=='fr'){echo "<b>L'arbre <span style=\"color:red;\"><i>".$nom_arbre."</i></span> a bien été modifié, vous pouvez <a class=\"rien\" href=\"brin.php?lang=".$lang."\">décrire ses caractéristiques</a>.</b><br/><br/>";}
			else {echo "<b>Tree <span style=\"color:red;\"><i>".$nom_arbre."</i></span> recorded, you can start <a class=\"rien\" href=\"brin.php?lang=".$lang."\">describing it</a>.</b><br/><br/>";
			}		
		} else {
			if ($lang=='fr'){echo "<b>L'arbre <span style=\"color:red;\"><i>".$nom_arbre."</i></span> a bien été modifié, vous pouvez <a class=\"rien\" href=\"modifier_brin.php?brin=".$data[uuid_brin]."&lang=".$lang."\">modifier ses caractéristiques</a>.</b><br/><br/>";}
			else {echo "<b>Tree <span style=\"color:red;\"><i>".$nom_arbre."</i></span> recorded, you can start <a class=\"rien\" href=\"modifier_brin.php?brin=".$data[uuid_brin]."&lang=".$lang."\">updating it</a>.</b><br/><br/>";
			}
		}
	} else {
	
		if ($lang=='fr'){echo "<b>L'arbre <span style=\"color:red;\"><i>".$nom_arbre."</i></span> a bien été modifié, vous pouvez <a class=\"rien\" href=\"modifier_cepee.php?arbre=".$_SESSION['uuid_arbre']."&lang=".$lang."\">(re)caractériser la cépée</a>.</b><br/><br/>";}
		else {echo "<b>Tree <span style=\"color:red;\"><i>".$nom_arbre."</i></span> recorded, you can start <a class=\"rien\" href=\"cepee.php?arbre=".$_SESSION['uuid_arbre']."&lang=".$lang."\">describing shrub</a>.</b><br/><br/>";}
	
	}		
		
		
		
	}	

} else {  /* ===================================== Remplissage du formulaire ====================================== */

   $uuid_manip = $_SESSION['uuid_manip'];
   $uuid_arbre = $_GET['arbre'];
  
$sql = "SELECT * FROM fraxpyr.arbre WHERE uuid_manip='$uuid_manip' AND uuid_arbre='$uuid_arbre'";
$res = pg_query($sql); 
$data = pg_fetch_array($res); ?>
 
<form action="modifier_arbre.php?mode=valid&lang=<? echo $lang; ?>&arbre=<? echo $uuid_arbre; ?>" method="post"> 


<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nom de l\'arbre';}else{echo '<b>Tree name</b>';} ?><br/><input type="text" name="nom_arbre" class="rech" onclick="this.style.backgroundColor='#DFF4B9';" value="<? echo $data['nom_arbre']; ?>"><br/><br/>

<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Genre';}else{echo 'Genus';} ?></b><br/>
<select name="genre" onclick="this.style.backgroundColor='#DFF4B9'" onchange="window.location='modifier_arbre.php?lang=<?php echo $lang; ?>&arbre=<? echo $uuid_arbre; ?>&genre='+this.value;">

                                <?
                                $sql = "SELECT DISTINCT id_genre, nom FROM genre ORDER BY nom";
                                $resultat = pg_query($sql);
                                if ($resultat === false) {
                                        echo "Erreur de connexion à la table des genres";
                                } else {
                                        while ($ligne=pg_fetch_assoc($resultat)) {
					if ($_GET[genre] != '') {$id_genre=$_GET[genre];}else{ $id_genre=$data['genre'];}
					if ($ligne['id_genre'] == $id_genre){$selected='SELECTED';}else{$selected='';}
                                        echo '<option '.$selected.' value="'.$ligne['id_genre'].'">'.$ligne['nom'].'</option>';
                                        }
                                }?>

</select>


<br/><br/>
<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Espèce';}else{echo 'Species';} ?></b><br/>

<select name="esp" onclick="this.style.backgroundColor='#DFF4B9'">

                                <?
                                if ($_GET[genre] != '') {$id_genre=$_GET[genre];}else{ $id_genre=$data['genre'];}
                                $sql2 = "SELECT DISTINCT id_espece, nom FROM espece WHERE id_genre='$id_genre' ORDER BY nom";
                                $resultat2 = pg_query($sql2);
                                if ($resultat2 === false) {
                                        echo "Erreur de connexion à la table des genres";
                                } else {
                                        while ($ligne2=pg_fetch_assoc($resultat2)) {
					$id_espece=$data['esp'];
					if ($ligne2['id_espece'] == $id_espece){$selected2='SELECTED';}else{$selected2='';}
                                        echo '<option '.$selected2.' value="'.$ligne2['id_espece'].'">'.$ligne2['nom'].'</option>';
                                        }
                                }?>

</select>
<br/><br/>


<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Morphologie';}else{echo 'Morphology';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="morpho" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['morpho'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['morpho'] == 'tronc unique'){echo 'SELECTED';} ?> value="tronc unique">Tronc unique</option>
<option <? if ($data['morpho'] == 'cépée'){echo 'SELECTED';} ?> value="cépée">Cépée</option>
</select><br/><br/>
<? } else { ?>
<select name="morph" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['morpho'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['morpho'] == 'tronc unique'){echo 'SELECTED';} ?> value="tronc unique">Single trunk</option>
<option <? if ($data['morpho'] == 'cépée'){echo 'SELECTED';} ?> value="cépée">Shrub</option>
</select><br/><br/>
<? } ?>


<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Localisation';}else{echo 'Location';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="localisation" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['localisation'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['localisation'] == 'isolé'){echo 'SELECTED';} ?> value="isolé">Isolé</option>
<option <? if ($data['localisation'] == 'haie'){echo 'SELECTED';} ?> value="haie">Haie</option>
<option <? if ($data['localisation'] == 'bosquet'){echo 'SELECTED';} ?> value="bosquet">Bosquet</option>
<option <? if ($data['localisation'] == 'ripisylve'){echo 'SELECTED';} ?> value="ripisylve">Ripisylve</option>
<option <? if ($data['localisation'] == 'forêt'){echo 'SELECTED';} ?> value="forêt">Forêt</option>
<option <? if ($data['localisation'] == 'lisière'){echo 'SELECTED';} ?> value="lisière">Lisière</option>
</select><br/><br/>
<? } else { ?>
<select name="localisation" onclick="this.style.backgroundColor='#DFF4B9'">
<option <? if ($data['localisation'] == '---'){echo 'SELECTED';} ?> value="---">---</option>
<option <? if ($data['localisation'] == 'isolé'){echo 'SELECTED';} ?> value="isolé">Isolated</option>
<option <? if ($data['localisation'] == 'haie'){echo 'SELECTED';} ?> value="haie">Hedge</option>
<option <? if ($data['localisation'] == 'bosquet'){echo 'SELECTED';} ?> value="bosquet">Grove</option>
<option <? if ($data['localisation'] == 'ripisylve'){echo 'SELECTED';} ?> value="ripisylve">Riparian forest</option>
<option <? if ($data['localisation'] == 'forêt'){echo 'SELECTED';} ?> value="forêt">Forest</option>
<option <? if ($data['localisation'] == 'lisière'){echo 'SELECTED';} ?> value="lisière">Edge</option>
</select><br/><br/>
<? } ?>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Photos';}else{echo '<b>Picture</b>';} ?><br/><input type="text" name="photo"  value="<? echo $data['photo']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Longitude';}else{echo '<b>Long</b>';} ?><br/><input type="text" name="lon"  value="<? echo $data['lon']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Latitude';}else{echo '<b>Lat</b>';} ?><br/><input type="text" name="lat"  value="<? echo $data['lat']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Commentaire';}else{echo '<b>Comment</b>';} ?><br/><textarea name="commentaire" class="texta" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><? echo $data['commentaire']; ?></textarea><br/><br/>

<input type="image" src="ok.png" align="absmiddle" title="Ok"> 

</form>

<?
}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



