<? include "connect_db.inc.php";
   session_start();
   $sql="DELETE FROM fraxpyr.releve WHERE uuid_releve='".$_GET['releve']."'";
   pg_query($sql); 
   header('location:recap.php?lang='.$_GET[lang].''); ?>
