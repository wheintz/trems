<?php
session_cache_limiter('private, must-revalidate');
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli DendoMicroHabitats</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA EasyTrems" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://dynafor.toulouse.inra.fr/dmh" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 8 jun 2016 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />
	
	<script type="text/javascript">
		function add( nom ) {
			document.getElementById( nom ).value ++;
		}
		function substract( nom ) {
			document.getElementById( nom ).value --;
		}

		function isNumberKey(evt) {
			var charCode = (evt.which) ? evt.which : event.keyCode
			if (charCode > 31 && (charCode < 48 || charCode > 57))
			return false;

			return true;
		}
		function Afficheetferme(nom){
			fichier = document.getElementById(nom);
			if (fichier.style.display == "none" ){
			fichier.style.display = "inline"
			}
			else {
			fichier.style.display = "none"
			}
		}
</script> 

</head>

<body>
<div id="global">
<div id="centralpres">
<? $lang=$_GET['lang']; ?>
<a href="releve.php?lang=<? echo $lang; ?>"><img border=0 src="home.png" align="absmiddle" title="Revenir au menu principal"></a>

<?php
$version = $_SESSION['version'];
$cond_version = "";

require 'connect_db.inc.php'; 

$lu=$_GET['lu'];
 $req="SELECT * FROM level1 WHERE level='$lu' $cond_version";
 $res=pg_query($req);
 $data=pg_fetch_array($res);
 
 if ($lang=='fr'){echo "<h1>".$data['label_fr']."</h1>";}else{echo "<h1>".$data['label_en']."</h1>";} ?>

&nbsp;&nbsp;&nbsp;<b><? if ($lang=='fr'){echo "Arbre en cours";}else{echo "Tree currently observed";} ?></b> :<span style="color:red;"> <?php echo $_SESSION['nom_arbre']; ?></span>

<?php

$l=$_GET['l'];

$luu=$_GET['luu'];
$ld=$l+1;
$ldd=$l+2;
$lup=$l-1;
$luup=$l-2;

echo '<form action="vreleve.php?l='.$l.'&lu='.$lu.'&lang='.$lang.'" method="post">';

$level_on='level'.$l;
$level_up='level'.$lu;
$level_down='level'.$ld;

$levelup='level'.$lup;
$leveluup='level'.$luup;


if($lu>1){

$sql3 = "SELECT * FROM $leveluup WHERE level='$luu' $cond_version ORDER BY level asc";
$res3 = pg_query($sql3);
$data3=pg_fetch_array($res3);
if ($lang=='fr'){
echo '<h2>';
echo $label=$data3[label_fr];
echo '</h2>';
} else {
echo '<h2>';
echo $label=$data3[label_en];
echo '</h2>';
}


$sql4 = "SELECT * FROM $levelup WHERE level='$lu' $cond_version ORDER BY level asc";
$res4 = pg_query($sql4);
$data4=pg_fetch_array($res4);
if ($lang=='fr'){
echo '<h3>';
echo $label=$data4[label_fr];
echo '</h3>';
} else {
echo '<h3>';
echo $label=$data4[label_en];
echo '</h3>';
}
}

$sql = "SELECT * FROM $level_on WHERE level_up='$lu' $cond_version ORDER BY level asc";
$res = pg_query($sql);
echo '<ul>';
		$j=0;
		while ($data=pg_fetch_array($res)) {
		$level=$data['level'];
		echo '<li><b>';
		echo $data['level'].' - ';
		if ($lang=='fr'){ echo $data['label_fr'];} else {echo $data['label_en'];}
		echo '</b>';
		echo '<br/>&nbsp;<input type="text" value="0" name="'.$data['level'].'" id="'.$data['level'].'" size="1" maxlength="4" onkeypress="return isNumberKey(event);">
					      &nbsp;&nbsp;&nbsp;<input type="button" class="plusmoins" style="width:40px;height:40px;" value="-" onclick="substract(\''.$data['level'].'\');">&nbsp;&nbsp;&nbsp;<input class="plusmoins" type="button" style="width:40px;height:40px;" value="+" onclick="add(\''.$data['level'].'\');">	';	
			$sql2 = "SELECT * FROM $level_down WHERE level_up=$level $cond_version ORDER BY level asc";
			$res2 = pg_query($sql2);
				echo '<br/><br/><ul>';
				$i=0;
				while ($data2=pg_fetch_array($res2)) {
					echo '<li>';
					if (($l==2) && ($data2['typo_simp']=='t')){
					echo '<span style="color:red;font-style:italic;">*'.$data2['level'].' - ';
					if ($lang=='fr'){ echo $data2['label_fr'];} else {echo $data2['label_en'];}
					echo '</span>';
					} else {
					echo $data2['level'].' - ';
					if ($lang=='fr'){ echo $data2['label_fr'];} else {echo $data2['label_en'];}
					}
					if (($l==6) OR ($l==2)){
						if ($lang=='fr'){ 
							echo '<br/><span class="infos" onClick="Afficheetferme(\'info'.$j.'-'.$i.'\');">DEF</span>';
							echo '&nbsp;&nbsp;<span class="infos" onClick="Afficheetferme(\'seuil'.$j.'-'.$i.'\');">SEUIL</span>';
							echo '<span id="info'.$j.'-'.$i.'" style="display:none;font-size:14px;line-height:30px;"><br/><fieldset>'.$data2['def_fr'].'</fieldset></span>';
							echo '<span id="seuil'.$j.'-'.$i.'" style="display:none;font-size:14px;line-height:30px;"><br/><fieldset>Valeur seuil : ['.$data2['valeur_seuil_fr'].']</fieldset></span>';} 
						else {echo '<br/><span class="infos" onClick="Afficheetferme(\'info'.$j.'-'.$i.'\');">DEF</span>';
							echo '&nbsp;&nbsp;<span class="infos" onClick="Afficheetferme(\'seuil'.$j.'-'.$i.'\');">SEUIL</span>';
							echo '<span id="info'.$j.'-'.$i.'" style="display:none;font-size:14px;line-height:30px;"><br/><fieldset>'.$data2['def_en'].'</fieldset></span>';
							echo '<span id="seuil'.$j.'-'.$i.'" style="display:none;font-size:14px;line-height:30px;"><br/><fieldset>Valeur seuil : '.$data2['valeur_seuil_en'].'</fieldset></span>';}					
					}
					if ($l==2){
					echo '&nbsp;&nbsp;<span class="infos" onClick="Afficheetferme(\'schema'.$j.'-'.$i.'\');">Schema</span>';
					echo '<span id="schema'.$j.'-'.$i.'" style="display:none;font-size:14px;line-height:30px;"><br/><fieldset style="width:200px;"><img src="../dmh/img/'.$data2[level].'.png"></fieldset></span>';}
					
					
					if (($l==6) OR ($l==2)){echo '';}else{echo '<br/>';}
					echo '&nbsp;&nbsp;&nbsp;<input type="text" value="0" id="'.$data2['level'].'" name="'.$data2['level'].'" size="1" maxlength="4" onkeypress="return isNumberKey(event);">
					      &nbsp;&nbsp;&nbsp;<input type="button" class="plusmoins" style="width:40px;height:40px;" value="-" onclick="substract(\''.$data2['level'].'\');">&nbsp;&nbsp;&nbsp;<input class="plusmoins" type="button" style="width:40px;height:40px;" value="+" onclick="add(\''.$data2['level'].'\');">	';
					if ($l<6){
						echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="trems.php?lu='.$data2['level'].'&l='.$ldd.'&luu='.$level.'&lang='.$lang.'"><img border=0 src="edit_ld.png" align="absmiddle" title="Enregistrer une observation au niveau plus fin"></a>';					
					}
					echo '</li><br/>';
				$i++;
				}
				echo '</ul>';		
		echo '</li>';
		$j++;
		}		
echo '</ul>';
?>
<input type="submit" name="submit" value="Ok" style="color:white;background-color:green;">
</form>
<br/>
</div>
</div>
<?php include('pdp.php');  ?>  

</body>



