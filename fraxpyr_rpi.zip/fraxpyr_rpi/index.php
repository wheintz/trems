<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli TREMS</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="Trems" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />
	<script type="text/javascript" src="calendrier.js"></script>

</head>

<body>
<div id="global">
<div id="centralpres">
<?php
require 'connect_db.inc.php'; 
$mode=$_GET[mode];


if ($mode == 'valid') { /* ===================================== Validation du formulaire ====================================== */

$lang=$_GET[lang];

if (empty($_POST['id_site'])){
		echo "<script>alert(\"Merci de renseigner un nom de site\")</script>";
		print "<script>history.back(); </script>";
		exit();}	
else {$id_site = pg_escape_string($_POST['id_site']);}

$date = $_POST['date'];


$manip = pg_escape_string($id_site).'-'.$date;

$req_verif="SELECT uuid_manip FROM fraxpyr.manip WHERE manip='$manip' AND id_site='$id_site'";
$res_verif=pg_query($req_verif);
$verif=pg_num_rows($res_verif);

if ($verif != '0'){
		echo "<script>alert(\"Cette combinaison manip/site existe déjà, merci de saisir une nouvelle combinaison\")</script>";
		print "<script>history.back(); </script>";
		exit();}


$obs = $_POST['obs'];
$notateur = $_POST['notateur'];

$reqdate=pg_query("SET datestyle TO DMY;");

$requete = "INSERT INTO fraxpyr.manip (manip,id_site,date,obs,notateur,uuid_manip) VALUES ('$manip','$id_site','$date','$obs','$notateur',uuid_generate_v4()) RETURNING uuid_manip";
	
	$result = pg_query($requete);
	$data = pg_fetch_array($result); 
	if( $result == FALSE ) {		
		echo "Une erreur s'est produite ...<br/>";
		echo '<!--'.$requete.'-->';
	} else {
		session_start();
		
		$_SESSION['uuid_manip'] = $data['uuid_manip'];
		$_SESSION['nom_manip'] = $manip;
	
		if ($lang=='fr'){echo "<br/><br/><b>Manip <span style=\"color:red;\"><i>".$manip."</i></span> enregistrée !<br/><br/>
		<a class=\"rien\" href=\"arbre.php?lang=".$lang."\">- Saisir un arbre</a><br/>
		<a href=\"index.php?reset=reset&lang=".$lang."\" class=\"rien\">- Changer de manip</a> </b><br/><br/><br/>
		";}
		else{echo "<br/><br/><b>Experience <span style=\"color:red;\"><i>".$manip."</i></span> recorded, you can :<br/><br/>
		 <a class=\"rien\" href=\"arbre.php?lang=".$lang."\">Register a tree</a>.<br/><br/>
		<a href=\"index.php?reset=reset&lang=".$lang."\" class=\"rien\">- Experience change</a></b><br/><br/>";}		
				
	}	

} else {  /* ===================================== Remplissage du formulaire ====================================== */

if ($_GET['reset'] == 'reset'){ 
    session_start();
    session_unset();
    session_destroy();
    session_write_close();
    setcookie(session_name(),'',0,'/');
    session_regenerate_id(true);
echo "<script>alert(\"La session en cours a été détruite, merci de saisir une nouvelle manip.\")</script>";
		
}

$lang=$_GET[lang];
$jour=date('d/m/Y');
if ($lang==''){$lang='fr';}

?>

<a href="index.php?lang=en"><img style="width:25px;margin-top:3px;" src="en.jpeg" title="Passer sur l'interface en anglais"></img></a>&nbsp;&nbsp; <a href="index.php?lang=fr"><img style="width:25px;margin-top:3px;" src="fr.jpeg" title="English interface"></img></a><br/><br/>

<a href="find_manip.php?lang=<?php echo $lang; ?>" class="rien">Charger une manip existante</a><br/><br/>

<form action="index.php?mode=valid&lang=<? echo $lang; ?>" method="post"> 

<b>Site </b><br/>
<select name="id_site" onclick="this.style.backgroundColor='#DFF4B9'">
<?
        $sql2 = "SELECT site FROM fraxpyr.site ORDER BY id_site";
        $resultat2 = pg_query($sql2);
                if ($resultat2 === false) {
                     echo "Erreur de connexion à la table des sites";
                } else {
                     while ($ligne2=pg_fetch_assoc($resultat2)) {

                        echo '<option value="'.$ligne2['site'].'">'.$ligne2['site'].'</option>';
                     }
}?>
</select>
<br/><br/>

<b>Date </b><br/><input type="text" name="date" value="<?php echo $jour; ?>" class="rech" onclick="ds_sh(this);this.style.backgroundColor='#DFF4B9';" /><br/><br/>
<table class="ds_box" cellpadding="0" cellspacing="0" id="ds_conclass" style="display: none;">
<tr><td id="ds_calclass"></td></tr>
</table>

<b><?php if ($lang=='' OR $lang=='fr'){echo 'Observateur';}else{echo 'Observer';} ?></b><br/><input type="text" name="obs" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>
<b><?php if ($lang=='' OR $lang=='fr'){echo 'Notateur';}else{echo 'Assessor';} ?></b><br/><input type="text" name="notateur" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>


<input type="image" src="ok.png" align="absmiddle" title="Ok"> 

</form>

<?
}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



