<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />


</head>

<body>
<? $lang=$_GET[lang]; ?>

<div id="global">
<div id="centralpres">

<?php 
	$manip = $_SESSION['nom_manip']; 
	$uuid_manip = $_SESSION['uuid_manip']; 
		
	if (($manip !='') && ($uuid_manip !='')){
	
		if ($lang=='fr'){echo "&nbsp;&nbsp;&nbsp;<fieldset><b>Manip en cours : <span style=\"color:red;\"><i>".$manip."</i></span> </fieldset><br/></br>
		<a class=\"rien\" href=\"arbre.php?lang=".$lang."\">- saisir un arbre</a><br/>
		<a href=\"index.php?reset=reset&lang=".$lang."\" class=\"rien\">- changer de manip</a> <br/>
		<a href=\"backup.php?lang=".$lang."\" class=\"rien\">- télécharger une copie des données</a> </b><br/><br/>
		";}
		else{echo "<br/><br/><b>Current experience <span style=\"color:red;\"><i>".$manip."</i></span> <br/></br>
		 <a class=\"rien\" href=\"arbre.php?lang=".$lang."\">register a tree</a>.<br/><br/>
		<a href=\"index.php?reset=reset&lang=".$lang."\" class=\"rien\">- Experience change</a><br/>
		<a href=\"backup.php?lang=".$lang."\" class=\"rien\">- Backup data</a> </b><br/><br/><br/><br/>";}
		
	} else {
	
	echo "<br/>Aucune manip active n'a été détectée, merci de <a href=\"index.php?lang=".$lang."\" class=\"rien\">saisir une manip</a><br/><br/>";
	
	}
?>

</center>
<br/>
</div>
</div>
<?php include('pdp.php');  ?>  

</body>



