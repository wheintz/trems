<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />

</head>

<body>
<? $lang=$_GET[lang]; ?>

<div id="global">
<div id="centralpres">
<a href="menu_cepee.php?lang=<?php echo $lang; ?>" class="rien"><? if ($lang=='fr'){echo "Menu cépée"; }else{echo "Shrub home";}?></a> &nbsp; 

| &nbsp; <a href="recap_cepee.php?lang=<?php echo $lang; ?>" class="rien"><? if ($lang=='fr'){echo "Récapitulatif des DMH saisis";}else{echo "Recorded Trems";}?></a><br/>


<center>
<map name="tree">
 <area shape="rect" coords="21,303,84,319" href="trems_cepee.php?l=2&lu=1&lang=<? echo $lang; ?>">
 <area shape="rect" coords="204,282,221,297" href="trems_cepee.php?l=2&lu=1&lang=<? echo $lang; ?>">
 <area shape="rect" coords="259,305,271,319" href="trems_cepee.php?l=2&lu=1&lang=<? echo $lang; ?>">
 <area shape="rect" coords="208,324,221,339" href="trems_cepee.php?l=2&lu=1&lang=<? echo $lang; ?>">
 <area shape="rect" coords="227,512,240,528" href="trems_cepee.php?l=2&lu=1&lang=<? echo $lang; ?>">
 <area shape="rect" coords="20,353,152,379" href="trems_cepee.php?l=2&lu=7&lang=<? echo $lang; ?>">
 <area shape="rect" coords="235,359,245,393" href="trems_cepee.php?l=2&lu=7&lang=<? echo $lang; ?>">
 <area shape="rect" coords="383,427,498,463" href="trems_cepee.php?l=2&lu=2&lang=<? echo $lang; ?>">
 <area shape="rect" coords="259,412,267,448" href="trems_cepee.php?l=2&lu=2&lang=<? echo $lang; ?>">
 <area shape="rect" coords="247,448,262,482" href="trems_cepee.php?l=2&lu=2&lang=<? echo $lang; ?>">
 <area shape="rect" coords="444,258,498,294" href="trems_cepee.php?l=2&lu=3&lang=<? echo $lang; ?>">
 <area shape="rect" coords="320,268,330,288" href="trems_cepee.php?l=2&lu=3&lang=<? echo $lang; ?>">
 <area shape="rect" coords="393,85,452,227" href="trems_cepee.php?l=2&lu=3&lang=<? echo $lang; ?>">
 <area shape="rect" coords="279,4,352,82" href="trems_cepee.php?l=2&lu=3&lang=<? echo $lang; ?>">
 <area shape="rect" coords="395,354,499,373" href="trems_cepee.php?l=2&lu=4&lang=<? echo $lang; ?>">
 <area shape="rect" coords="252,360,284,397" href="trems_cepee.php?l=2&lu=4&lang=<? echo $lang; ?>">
 <area shape="rect" coords="204,126,231,154" href="trems_cepee.php?l=2&lu=4&lang=<? echo $lang; ?>">
 <area shape="rect" coords="17,406,105,442" href="trems_cepee.php?l=2&lu=5&lang=<? echo $lang; ?>">
 <area shape="rect" coords="214,424,240,447" href="trems_cepee.php?l=2&lu=5&lang=<? echo $lang; ?>">
 <area shape="rect" coords="15,167,96,218" href="trems_cepee.php?l=2&lu=6&lang=<? echo $lang; ?>">
 <area shape="rect" coords="193,164,253,304" href="trems_cepee.php?l=2&lu=6&lang=<? echo $lang; ?>">
 <area shape="rect" coords="159,256,190,279" href="trems_cepee.php?l=2&lu=6&lang=<? echo $lang; ?>">
 <area shape="rect" coords="19,476,125,505" href="trems_cepee.php?l=2&lu=8&lang=<? echo $lang; ?>">
 <area shape="rect" coords="100,546,136,588" href="trems_cepee.php?l=2&lu=8&lang=<? echo $lang; ?>">
 <area shape="rect" coords="283,576,375,592" href="trems_cepee.php?l=2&lu=9&lang=<? echo $lang; ?>">
 <area shape="rect" coords="352,624,432,637" href="trems_cepee.php?l=2&lu=9&lang=<? echo $lang; ?>">
 <area shape="rect" coords="402,529,432,609" href="trems_cepee.php?l=2&lu=9&lang=<? echo $lang; ?>">
</map>



<?php

	if ($lang == 'fr' OR $lang=''){ echo '<img src="arbre_fr.png" usemap="#tree" border=0 width="500">';}
	else { echo '<img src="arbre_en.png" usemap="#tree" border=0 width="500">';} 


?>
</center>
<br/>
</div>
</div>
<?php include('pdp.php');  ?>  

</body>



