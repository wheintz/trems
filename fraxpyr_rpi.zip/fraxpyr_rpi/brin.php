<? $lang=$_GET[lang]; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />
	<script language="javascript" type="application/javascript">
	function Affiche(nom){
		fichier = document.getElementById(nom)
		if (fichier.style.display == "none" ){
			fichier.style.display = "inline"
		}
		else {
			fichier.style.display = "none"
		}
	}
	function Ferme(nom){
		fichier = document.getElementById(nom)
			if (fichier.style.display == "inline" ){
			fichier.style.display = "none"
			}
		}
	</script>

</head>

<body>
<div id="global">
<div id="centralpres">
<?php
session_start();
require 'connect_db.inc.php'; 
$mode=$_GET[mode];


if ($lang=='fr'){echo '<a href="index.php?reset=reset&lang='.$lang.'" class="rien">Changer manip</a> | ';}else{echo '<a href="index.php?reset=reset&lang='.$lang.'" class="rien">Experience change</a> | ';} 

if ($lang=='fr'){echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Accueil manip</a> | ';}else{echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Experience home</a> | ';} 

if ($_SESSION['uuid_cepee'] != '') {
if ($lang=='fr'){echo '<a href="menu_cepee.php?lang='.$lang.'" class="rien">Menu cépée</a><br/><br/>';}else{echo '<a href="menu_cepee.php?lang='.$lang.'" class="rien">Shrub home</a>';} 
}
echo "<br/><br/>";
if ($mode == 'valid') { /* ===================================== Validation du formulaire ====================================== */



$uuid_manip=$_SESSION['uuid_manip'];
$uuid_arbre=$_SESSION['uuid_arbre'];

$dbh = $_POST['dbh'];
$num_brin = $_POST['num_brin'];	
$forme = $_POST['forme'];
$gestion = $_POST['gestion'];
$dia_br = $_POST['dia_br'];

$photo = $_POST['photo'];
$htot = $_POST['htot'];
$hfut = $_POST['hfut'];
$dhref = $_POST['dhref'];

$nb_br20_fut = $_POST['nb_br20_fut'];
$nb_br20sup_fut = $_POST['nb_br20sup_fut'];
$nb_br20_tete = $_POST['nb_br20_tete'];
$nb_br20sup_tete = $_POST['nb_br20sup_tete'];
$commentaire = $_POST['commentaire'];


$requete = "INSERT INTO fraxpyr.brin (num_brin,dbh,forme,gestion,htot,hfut,dhref,nb_br20_fut,nb_br20sup_fut,nb_br20_tete,nb_br20sup_tete,
commentaire,photo,dia_br,uuid_arbre,uuid_manip,uuid_brin) VALUES ('$num_brin','$dbh','$forme','$gestion','$htot','$hfut','$dhref','$nb_br20_fut',
'$nb_br20sup_fut','$nb_br20_tete','$nb_br20sup_tete','$commentaire','$photo','$dia_br','$uuid_arbre','$uuid_manip',uuid_generate_v4()) RETURNING uuid_brin,num_brin";
	
	$result = pg_query($requete); 
	$data = pg_fetch_array($result);
	if( $result == FALSE ) {		
		echo "Une erreur s'est produite ...<br/>";
		echo '<!--'.$requete.'-->';
	} else {
		session_start();
		unset($_SESSION['uuid_brin']); unset($_SESSION['num_brin']);
		$_SESSION['uuid_brin'] = $data['uuid_brin'];
		$_SESSION['num_brin'] = $num_brin;
	
	if ($lang=='fr'){echo "<b>Le brin <span style=\"color:red;\"><i>".$num_brin."</i></span> a bien été enregistré, vous pouvez <a class=\"rien\" href=\"releve.php?lang=".$lang."\">commencer la saisie de micro-habitats</a>.</b><br/><br/>";}
	else {echo "<b>Strand <span style=\"color:red;\"><i>".$num_brin."</i></span> recorded, you can start <a class=\"rien\" href=\"releve.php?lang=".$lang."\">recording trems</a>.</b><br/><br/>";}		
		
		
		
	}	

} else {  /* ===================================== Remplissage du formulaire ====================================== */

if ($_GET['reset'] == 'reset'){ unset($_SESSION['uuid_brin']);unset($_SESSION['num_brin']);}

?>


<form action="brin.php?mode=valid&lang=<? echo $lang; ?>" method="post"> 
<br/>
<b>Numéro ou nom du brin </b><br/><input type="text" name="num_brin" id="num_brin" value="Numéro/nom du brin" class="rech" onclick="this.style.backgroundColor='#DFF4B9';"><br/><br/>

<b>DBH </b><br/><input type="text" name="dbh" id="dbh" value="Diamètre à 130cm" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<b>Diamètre à mi-hauteur </b><br/><input type="text" name="dhref" id="dhref" value="Diamètre à mi-hauteur" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>


<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Forme';}else{echo 'Shape';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="forme" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="libre">Libre</option>
<option value="têtard">Têtard</option>
<option value="émondé">Émondé</option>
<option value="cépée">Cépée</option>
<option value="coupe ponctuelle">Coupe ponctuelle</option>
</select><br/><br/>

<? } else { ?>
<select name="forme" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="libre">Free</option>
<option value="têtard">Têtard</option>
<option value="émondé">Trimmed</option>
<option value="cépée">Shrub</option>
<option value="coupe ponctuelle">Ponctual cut</option>
</select><br/><br/>
<? } ?>


<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Sévérité de la gestion';}else{echo 'Management';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="gestion" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="0">Aucune</option>
<option value="1">Faible</option>
<option value="2">Forte</option>
</select><br/><br/>

<? } else { ?>
<select name="gestion" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="0">None</option>
<option value="1">Low</option>
<option value="2">High</option>
</select><br/><br/>
<? } ?>

<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Diamètre branches dernière coupe visible';}else{echo 'Last cut Branch diameter';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="dia_br" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="< 5cm">< 5cm</option>
<option value="5-10cm">5-10cm</option>
<option value="10-20cm">10-20cm</option>
<option value="> 20cm">> 20cm</option>
</select><br/><br/>

<? } else { ?>
<select name="dia_br" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option value="< 5cm">< 5cm</option>
<option value="5-10cm">5-10cm</option>
<option value="10-20cm">10-20cm</option>
<option value="> 20cm">> 20cm</option>
</select><br/><br/>
<? } ?>


<?php if ($lang=='' OR $lang=='fr'){echo '<b>Hauteur totale';}else{echo '<b>Tree height </b>';} ?><br/><input type="text" name="htot" class="rech" value="Hauteur totale" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Hauteur du fut';}else{echo '<b>Bole height </b>';} ?><br/><input type="text" name="hfut" class="rech" value="Hauteur du fût" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nb de branches (10-20cm) sur le fût';}else{echo '<b>Nb branches 10-20 trunk </b>';} ?><br/><input type="text" name="nb_br20_fut" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nb de branches (>20cm) sur le fût';}else{echo '<b>Nb branches >20 trunk </b>';} ?><br/><input type="text" name="nb_br20sup_fut" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nb de branches/brins (10-20cm) sur la tête';}else{echo '<b>Nb branches 10-20 head </b>';} ?><br/><input type="text" name="nb_br20_tete" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nb de branches/brins (>20cm) sur la tête';}else{echo '<b>Nb branches >20 head </b>';} ?><br/><input type="text" name="nb_br20sup_tete" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Photos';}else{echo '<b>Pictures</b>';} ?><br/><input type="text" name="photo" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Commentaire';}else{echo '<b>Comment</b>';} ?><br/><textarea name="commentaire" class="texta" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"></textarea><br/><br/>

<input type="image" src="ok.png" align="absmiddle" title="Ok"> 

</form>

<?
}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



