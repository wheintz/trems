<? $lang=$_GET[lang]; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />
	<script language="javascript" type="application/javascript">
	function Affiche(nom){
		fichier = document.getElementById(nom)
		if (fichier.style.display == "none" ){
			fichier.style.display = "inline"
		}
		else {
			fichier.style.display = "none"
		}
	}
	function Ferme(nom){
		fichier = document.getElementById(nom)
			if (fichier.style.display == "inline" ){
			fichier.style.display = "none"
			}
		}
	</script>

</head>

<body>
<div id="global">
<div id="centralpres">
<?php
session_start();
require 'connect_db.inc.php'; 
$mode=$_GET[mode];


if ($lang=='fr'){echo '<a href="index.php?reset=reset&lang='.$lang.'" class="rien">Changer manip</a> | ';}else{echo '<a href="index.php?reset=reset&lang='.$lang.'" class="rien">Experience change</a> | ';} 

if ($lang=='fr'){echo '<a href="find_arbre.php?lang='.$lang.'" class="rien">Liste arbres </a> | ';}else{echo '<a href="find_arbre.php?lang='.$lang.'" class="rien">Tree already recorded</a> | ';} 

if ($lang=='fr'){echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Accueil manip</a><br/><br/>';}else{echo '<a href="menu_manip.php?lang='.$lang.'" class="rien">Experience home</a><br/><br/>';} 

if ($mode == 'valid') { /* ===================================== Validation du formulaire ====================================== */



$uuid_manip=$_SESSION['uuid_manip'];
$uuid_arbre=$_SESSION['uuid_arbre'];
$nb_brin = $_POST['nb_brin'];
$pbase = $_POST['pbase'];
$commentaire = $_POST['commentaire'];


$requete = "INSERT INTO fraxpyr.cepee (nb_brin,pbase,commentaire,uuid_arbre,uuid_cepee,uuid_manip) VALUES ('$nb_brin','$pbase','$commentaire','$uuid_arbre',uuid_generate_v4(),'$uuid_manip') RETURNING uuid_cepee";
	
	$result = pg_query($requete); 
	$data = pg_fetch_array($result);
	if( $result == FALSE ) {		
		echo "Une erreur s'est produite ...<br/>";
		echo '<!--'.$requete.'-->';
	} else {
		session_start();
		$_SESSION['uuid_cepee'] = $data['uuid_cepee'];
				
		
	
	
		if ($lang=='fr'){echo "<b>La cépée a bien été enregistrée, vous pouvez : <br/><br/>- <a class=\"rien\" href=\"releve_cepee.php?lang=".$lang."\">saisir ses microhabitats</a><br/>
		- <a class=\"rien\" href=\"brin.php?lang=".$lang."\">décrire ses brins</a>.</b><br/><br/>";}
		else {echo "<b>Shrub recorded, you can start:<br/><br/> - <a class=\"rien\" href=\"releve_cepee.php?lang=".$lang."\">describing trems</a><br/>
		
		- <a class=\"rien\" href=\"brin.php?lang=".$lang."\">describing strands</a>.";}		
	
	
		
		
    }	

} else {  /* ===================================== Remplissage du formulaire ====================================== */

if ($_GET['reset'] == 'reset'){ unset($_SESSION['uuid_cepee']);}

?>


<form action="cepee.php?mode=valid&lang=<? echo $lang; ?>" method="post"> 


<?php if ($lang=='' OR $lang=='fr'){echo '<b>Périmètre de base';}else{echo '<b>Base perimeter</b>';} ?><br/><input type="text" name="pbase" class="rech" onclick="this.style.backgroundColor='#DFF4B9';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Nombre de brins';}else{echo '<b>Strands quantity</b>';} ?><br/><input type="text" name="nb_brin" class="rech" onclick="this.style.backgroundColor='#DFF4B9';"><br/><br/>

<?php if ($lang=='' OR $lang=='fr'){echo '<b>Commentaire';}else{echo '<b>Comment</b>';} ?><br/><textarea name="commentaire" class="texta" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"></textarea><br/><br/>

<input type="image" src="ok.png" align="absmiddle" title="Ok"> 

</form>

<?
}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



