<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli ClimTree</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />

</head>

<body>
<div id="global">
<div id="centralpres">
<?php
require 'connect_db.inc.php'; 
$mode=$_GET[mode];


if ($mode == 'valid') { /* ===================================== Validation du formulaire ====================================== */

$lang=$_GET[lang];

if (empty($_POST['id_site'])){
		echo "<script>alert(\"Merci de renseigner un nom de site\")</script>";
		print "<script>history.back(); </script>";
		exit();}	
else {$id_site = $_POST['id_site'];}

$date = $_POST['date'];
$id_plot = $_POST['id_plot'];
$obs = $_POST['obs'];
$notateur = $_POST['notateur'];
if (empty($_POST['num_arbre'])){
		echo "<script>alert(\"Merci de renseigner un numéro d'arbre\")</script>";
		print "<script>history.back(); </script>";
		exit();}	
else {
$test_num_arbre = $_POST['num_arbre'];
$verif=pg_query("SELECT id_arbre FROM climtree.arbre WHERE num_arbre='$test_num_arbre'");
$tot=pg_num_rows($verif);
	if ($tot>0){ 
		echo "<script>alert(\"Ce numéro d'arbre existe déjà !\")</script>";
		print "<script>history.back(); </script>";
		exit();}
	else {$num_arbre = $_POST['num_arbre'];
	}

}
$genre = $_POST['genre'];
$esp = $_POST['esp'];
$dbh = $_POST['dbh'];
$statut = $_POST['statut'];

$requete = "INSERT INTO climtree.arbre (id_site,date,id_plot,obs,notateur,num_arbre,genre,esp,dbh,statut) VALUES ('$id_site','$date','$id_plot','$obs','$notateur','$num_arbre','$genre','$esp','$dbh','$statut')";
	
	$result = pg_query($requete); 
	if( $result == FALSE ) {		
		echo "Une erreur s'est produite ...<br/>";
		echo '<!--'.$requete.'-->';
	} else {
		session_start();
		$_SESSION['arbre'] = $num_arbre;
	
		echo "<br/><br/><b>L'arbre <span style=\"color:red;\"><i>".$_SESSION['arbre']."</i></span> a bien été enregistré, vous pouvez <a href=\"releve.php?lang=".$lang."\">commencer la saisie de micro-habitats</a>.</b><br/><br/>";		
	}	

} else {  /* ===================================== Remplissage du formulaire ====================================== */

if ($mode == 'reset'){ session_unset();}

?>

<a href="index.php?lang=en"><img style="width:25px;margin-top:3px;" src="en.jpeg" title="Passer sur l'interface en anglais"></img></a>&nbsp;&nbsp; <a href="index.php?lang=fr"><img style="width:25px;margin-top:3px;" src="fr.jpeg" title="Passer sur l'interface en français"></img></a><br/><br/>



<form action="index.php?mode=valid&lang=<? echo $lang; ?>" method="post"> 

<b>Site </b><br/><input type="text" name="id_site" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>
<b>Date </b><br/><input type="text" value="jj/mm/aaaa" name="date" class="rech" onclick="this.style.backgroundColor='#DFF4B9';this.value='';"><br/><br/>
<b>Plot </b><br/><input type="text" name="id_plot" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>
<b>Observateur </b><br/><input type="text" name="obs" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>
<b>Notateur </b><br/><input type="text" name="notateur" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>
<b>Arbre </b><br/><input type="text" name="num_arbre" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>
<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Genre';}else{echo 'Genus';} ?></b><br/>

<select name="genre" onclick="this.style.backgroundColor='#DFF4B9'" onchange="window.location='arbre.php?lang=<?php echo $lang; ?>&genre='+this.value;">

                                <?
                                $sql = "SELECT DISTINCT id_genre, nom FROM genre ORDER BY nom";
                                $resultat = pg_query($sql);
                                if ($resultat === false) {
                                        echo "Erreur de connexion à la table des genres";
                                } else {
                                	$id_genre=$_GET[genre];
					if ($id_genre==''){echo '<option SELECTED value="">---</option>';}
                                        while ($ligne=pg_fetch_assoc($resultat)) {					
					if ($ligne['id_genre'] == $id_genre){$selected='SELECTED';}else{$selected='';}
                                        echo '<option '.$selected.' value="'.$ligne['id_genre'].'">'.$ligne['nom'].'</option>';
                                        }
                                }?>

</select>


<br/><br/>
<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Espèce';}else{echo 'Species';} ?></b><br/>

<select name="esp" onclick="this.style.backgroundColor='#DFF4B9'">

                                <?
                                $id_genre=$_GET[genre];
                                $sql2 = "SELECT DISTINCT id_espece, nom FROM espece WHERE id_genre='$id_genre' ORDER BY nom";
                                $resultat2 = pg_query($sql2);
                                if ($resultat2 === false) {
                                        echo "Erreur de connexion à la table des espèces";
                                } else {
                                        while ($ligne2=pg_fetch_assoc($resultat2)) {

                                        echo '<option value="'.$ligne2['id_espece'].'">'.$ligne2['nom'].'</option>';
                                        }
                                }?>

</select><br/><br/>
<b>DBH </b><br/><input type="text" name="dbh" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>

<b> <?php if ($lang=='' OR $lang=='fr'){echo 'Statut';}else{echo 'Status';} ?></b><br/><?php if ($lang=='' OR $lang=='fr'){ ?>
<select name="statut" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="---">---</option>
<option onclick="document.getElementById('dbh').value='D à 1m30 (précomptage > 17.5)';" value="vivant">Vivant ou dépérissant</option>
<option onclick="document.getElementById('dbh').value='D à H/2 (précomptage > 7.5)';" value="souche">Souche et chandelle courte (1m < H < 4m)</option>
<option onclick="document.getElementById('dbh').value='D à 1m30 (précomptage > 7.5)';" value="chandelle">Chandelle haute (H > 4m)</option>
<option onclick="document.getElementById('dbh').value='D à H/2 (précomptage > 17.5)';" value="bois mort au sol">Bois mort au sol</option>
</select><br/><br/>

<? } else { ?>
<select name="statut" onclick="this.style.backgroundColor='#DFF4B9'">
<option value="vivant">Living</option>
<option value="souche">Stump and short snag (1m < H < 4m)</option>
<option value="chandelle">High snag (H > 4m)</option>
<option value="bois mort au sol">Log</option>
</select><br/><br/>
<? } ?>

<input type="image" src="ok.png" align="absmiddle" title="Valider la saisie"> 

</form>

<?
}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



