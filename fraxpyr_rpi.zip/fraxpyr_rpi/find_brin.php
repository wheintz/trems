<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli DendoMicroHabitats</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />
	<script language="javascript" type="text/javascript">
		function verif(){
            if (window.confirm('Cet arbre sera effacé / tree will be deleted')) {
               return true;
            } else {
               return false;
            }
	}
	</script>
</head>

<body>
<? $lang=$_GET[lang]; ?>

<div id="global">
<div id="centralpres">
<? if ($lang=='fr'){ ?><a href="arbre.php?lang=<?php echo $lang; ?>" class="rien">Retour</a> <? } else { ?>  <a href="arbre.php?lang=<?php echo $lang; ?>" class="rien">Back</a> <? } ?>

<br/>
&nbsp;&nbsp;&nbsp;<fieldset><b><? if ($lang=='fr'){echo "Manip en cours";}else{echo "Current experience";} ?></b> :<span style="color:red;"> <?php echo $_SESSION['nom_manip']; ?></span></fieldset><br/>

<?php
require 'connect_db.inc.php'; 
$uuid_manip = $_SESSION['uuid_manip'];
$uuid_arbre = $_SESSION['uuid_arbre'];
$sql = "SELECT uuid_brin, num_brin, dbh, forme FROM fraxpyr.brin WHERE uuid_manip='$uuid_manip' AND uuid_arbre='$uuid_arbre' ORDER BY date_creation DESC";
$res = pg_query($sql);
$count = pg_num_rows($res);

if ($lang=='fr'){echo 'Il y a '.$count.' brin(s) enregistré(s) pour cette manip.<br/>';}
else {echo $count.' strands(s) currently recorded.<br/>';}


echo '<ul>';
while ($data=pg_fetch_array($res)){
	echo "<table><tr>";
	echo "<td><li>".$data['num_brin']." (".$data['forme'].")</td>";
	
	
	echo "<td>&nbsp;&nbsp;<a href=\"modifier_brin.php?brin=".$data['uuid_brin']."&lang=".$lang."\" title=\"Charger et modifier cet brin\"><input type=\"image\" src=\"./download.png\" align=\"absmiddle\"></a></td>";
	echo "<td><form action=\"effacer_brin.php?brin=".$data['uuid_brin']."&lang=".$lang."\" method=\"post\" onSubmit=\"return verif();\">&nbsp;&nbsp;<input type=\"image\" src=\"./trash.png\" align=\"absmiddle\"  title=\"Effacer ce brin\"></form></td></tr></table></li>";
	
	
	
}
echo '</ul>';
?>

</center>
<br/>
</div>
</div>
<?php include('pdp.php');  ?>  

</body>



