<? $lang=$_GET[lang]; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />


</head>

<body>

<div id="global">
<div id="centralpres">
<?php
session_start();
require 'connect_db.inc.php'; 
$mode=$_GET[mode];


if ($mode == 'valid') { /* ===================================== Validation du formulaire ====================================== */

$lang=$_GET[lang];
$uuid_manip=$_GET[manip];

if (empty($_POST['id_site'])){
		echo "<script>alert(\"Merci de renseigner un nom de site\")</script>";
		print "<script>history.back(); </script>";
		exit();}	
else {$id_site = pg_escape_string($_POST['id_site']);}

$date = $_POST['date'];


$manip = $id_site.'-'.$date;

$obs = $_POST['obs'];
$notateur = $_POST['notateur'];

$requete = "UPDATE fraxpyr.manip SET manip='$manip',id_site='$id_site',date='$date',obs='$obs',notateur='$notateur' WHERE uuid_manip='$uuid_manip' RETURNING manip";
	
	$result = pg_query($requete);
	$data = pg_fetch_array($result); 
	if( $result == FALSE ) {		
		echo "Une erreur s'est produite ...<br/>";
		echo '<!--'.$requete.'-->';
	} else {
		session_start();
		$_SESSION['uuid_manip'] = $uuid_manip;
		$_SESSION['nom_manip'] = $data['manip'];
	
		if ($lang=='fr'){echo "<br/><br/><b>La manip <span style=\"color:red;\"><i>".$manip."</i></span> a bien été enregistrée, vous pouvez :<br/><br/>
		<a class=\"rien\" href=\"arbre.php?lang=".$lang."\">- Saisir un arbre</a><br/>
		<a href=\"index.php?reset=reset&lang=".$lang."\" class=\"rien\">- Changer de manip</a> </b><br/><br/><br/>
		";}
		else{echo "<br/><br/><b>Experience <span style=\"color:red;\"><i>".$manip."</i></span> recorded, you can :<br/><br/>
		 <a class=\"rien\" href=\"arbre.php?lang=".$lang."\">Register a tree</a>.<br/><br/>
		<a href=\"index.php?reset=reset&lang=".$lang."\" class=\"rien\">- Experience change</a></b><br/><br/>";}		
				
	}	

} else {  /* ===================================== Remplissage du formulaire ====================================== */

$uuid_manip=$_GET[manip];
$lang=$_GET[lang];

if ($lang==''){$lang='fr';}

$sql = "SELECT * FROM fraxpyr.manip WHERE uuid_manip='$uuid_manip'";
$res = pg_query($sql); 
$data = pg_fetch_array($res); 

?>

<form action="modifier_manip.php?mode=valid&lang=<? echo $lang; ?>&manip=<? echo $uuid_manip; ?>" method="post"> 

<b>Site </b><br/>
<select name="id_site" onclick="this.style.backgroundColor='#DFF4B9'">
<?

	$sql2 = "SELECT site FROM fraxpyr.site ORDER BY site";
        $resultat2 = pg_query($sql2);
                if ($resultat2 === false) {
                     echo "Erreur de connexion à la table des sites";
                } else {
                     while ($ligne2=pg_fetch_array($resultat2)) {

                        if ($data['id_site']==$ligne2['site']){echo '<option SELECTED value="'.$ligne2['site'].'">'.$ligne2['site'].'</option>';}
                        else {echo '<option value="'.$ligne2['site'].'">'.$ligne2['site'].'</option>';}
                     }
		}
	
?>
</select>
<br/><br/>

<b>Date </b><br/><input type="text" name="date" value="<?php echo $data['date']; ?>" class="rech" onclick="ds_sh(this);this.style.backgroundColor='#DFF4B9';" /><br/><br/>
<table class="ds_box" cellpadding="0" cellspacing="0" id="ds_conclass" style="display: none;">
<tr><td id="ds_calclass"></td></tr>
</table>

<b><?php if ($lang=='' OR $lang=='fr'){echo 'Observateur';}else{echo 'Observer';} ?></b><br/><input type="text" name="obs" value="<?php echo $data['obs']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>
<b><?php if ($lang=='' OR $lang=='fr'){echo 'Notateur';}else{echo 'Assessor';} ?></b><br/><input type="text" name="notateur" value="<?php echo $data['notateur']; ?>" class="rech" onclick="this.style.backgroundColor='#DFF4B9'"><br/><br/>


<input type="image" src="ok.png" align="absmiddle" title="Ok"> 

</form>

<?
}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



