<? $lang=$_GET[lang]; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Appli fraxpyr</title>
    <link href="./dmh.css" type="text/css" rel="stylesheet" media="screen" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<meta name="description" content="INRA IBP" />
	<meta name="Author" lang="fr" content="INRA Dynafor" />
	<meta name="Publisher" content="INRA Dynafor" />
	<meta name="Reply-to" content="" />
	<meta name="Keywords" content="changement climatique biodiversité" />
	<meta name="Indentifier-URL" content="http://www.gip-ecofor.org" />
	<meta name="Generator" content="ConText, Mozilla Firefox" />
	<meta name="verify-v1" content="9S2ANJdaQxiGv1m0HarZD1qHZzFhILMU0C0mMW/A4h0=" />
	<meta name="Date" content="Wed, 7 jan 2010 11:30:00" />
	<meta name="Robots" content="All" />
	<meta name="Revisit-after" content='5' />
	<script language="javascript" type="application/javascript">
	function Affiche(nom){
		fichier = document.getElementById(nom)
		if (fichier.style.display == "none" ){
			fichier.style.display = "inline"
		}
		else {
			fichier.style.display = "none"
		}
	}
	function Ferme(nom){
		fichier = document.getElementById(nom)
			if (fichier.style.display == "inline" ){
			fichier.style.display = "none"
			}
		}
	</script>

</head>

<body>
<div id="global">
<div id="centralpres">
<?php

require 'connect_db.inc.php'; 

$requete = "SELECT uuid_arbre FROM fraxpyr.arbre";
	
	$result = pg_query($requete); 
	while ($data = pg_fetch_array($result)){
		echo $uuid_arbre=$data[uuid_arbre];
		
		$req2= pg_query("SELECT num_arbre FROM fraxpyr.releve WHERE uuid_arbre='$uuid_arbre'");
		$data2=pg_fetch_array($req2);
		
		$num_arbre=$data2[num_arbre];
	
		if ($num_arbre != ''){
		pg_query("UPDATE fraxpyr.arbre SET num_arbre='$num_arbre' WHERE uuid_arbre='$uuid_arbre'");
		echo ' done <br/>';
		} else {
		pg_query("UPDATE fraxpyr.arbre SET num_arbre='pas fait' WHERE uuid_arbre='$uuid_arbre'");
		echo ' <b>pas done</b><br/>';}
		
	}
?>
</div>
<br/>

<? include('pdp.php');  ?>  

</body>



