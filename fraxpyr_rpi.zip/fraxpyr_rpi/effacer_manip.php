<? include "connect_db.inc.php";
   session_start();
   if ($_GET['manip'] == $_SESSION['uuid_manip']){ 
   	if ($_GET[lang]=='fr'){echo "<script>alert(\"Vous ne pouvez pas effacer la manip en cours ! \")</script>";}
   	else {echo "<script>alert(\"You cannot delete the current experience \")</script>";}
	print "<script>history.back(); </script>";
	exit();
   	
   	} else {   
   	$uuid_manip = $_GET['manip'];
	$verif = "SELECT * FROM fraxpyr.arbre WHERE uuid_manip='$uuid_manip'";
	$res = pg_query($verif);
	if (pg_num_rows($res)>0){
		if ($_GET[lang]=='fr') {echo "<script>alert(\"Des arbres existent pour cette manip, merci de les supprimer préalablement \")</script>";}
   		else {echo "<script>alert(\"Trees are linked to this experience, please delete them before \")</script>";}
		print "<script>history.back(); </script>";
	
	} else {
   	$uuid_manip = $_GET['manip'];
   	$sql="DELETE FROM fraxpyr.manip WHERE uuid_manip='".$uuid_manip."'";
   	pg_query($sql);
   
   	echo "<script>alert(\"Ok \")</script>";
   	header('location:find_manip.php?lang='.$_GET['lang'].'');
   	}
   }	
   
  ?>
